<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entbann-Anträge - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Entbann-Anträge</h1>
                <p class="page-subtitle"><?= count(array_filter($requests, fn($r) => $r['status'] === 'pending')) ?> offene Anträge</p>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <?php if (empty($requests)): ?>
                <div class="card">
                    <p class="text-muted text-center" style="padding: 2rem;">Keine Entbann-Anträge vorhanden</p>
                </div>
            <?php else: ?>
                <div style="display: grid; gap: 1rem;">
                    <?php foreach ($requests as $request): ?>
                    <div class="card">
                        <div class="flex justify-between items-center mb-3">
                            <div>
                                <span class="ip-display"><?= htmlspecialchars($request['ip']) ?></span>
                                <?php if (!empty($request['email'])): ?>
                                    <span class="text-small text-muted ml-2"><?= htmlspecialchars($request['email']) ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="badge badge-<?= $request['status'] === 'pending' ? 'warning' : ($request['status'] === 'approved' ? 'success' : 'danger') ?>">
                                <?= $request['status'] === 'pending' ? 'Offen' : ($request['status'] === 'approved' ? 'Genehmigt' : 'Abgelehnt') ?>
                            </span>
                        </div>
                        
                        <div class="card" style="background: var(--bg-primary); margin-bottom: 1rem;">
                            <p class="text-small"><?= nl2br(htmlspecialchars($request['message'])) ?></p>
                            <p class="text-xs text-muted mt-2"><?= formatDateTime($request['created_at']) ?></p>
                        </div>
                        
                        <?php if (!empty($request['admin_response'])): ?>
                        <div class="card" style="background: var(--success-bg); border-color: var(--success);">
                            <p class="text-small text-muted mb-1">Admin-Antwort:</p>
                            <p class="text-small"><?= nl2br(htmlspecialchars($request['admin_response'])) ?></p>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($request['status'] === 'pending'): ?>
                        <div class="flex gap-2 mt-3">
                            <form method="POST" style="flex: 1;">
                                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                <input type="hidden" name="action" value="approve">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <input type="text" name="response" class="form-input mb-2" placeholder="Antwort (optional)">
                                <button type="submit" class="btn btn-success" style="width: 100%;">
                                    Genehmigen & Entbannen
                                </button>
                            </form>
                            <form method="POST" style="flex: 1;">
                                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <input type="text" name="response" class="form-input mb-2" placeholder="Ablehnungsgrund">
                                <button type="submit" class="btn btn-danger" style="width: 100%;">
                                    Ablehnen
                                </button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>
