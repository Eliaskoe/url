<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entbannung beantragen - URL Shortener</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php
    $submitted = false;
    $error = null;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            $error = 'Ungültige Anfrage. Bitte versuchen Sie es erneut.';
        } elseif (empty($_POST['message'])) {
            $error = 'Bitte geben Sie eine Nachricht ein.';
        } else {
            $storage->createUnbanRequest([
                'ip' => $security->getClientIP(),
                'email' => sanitize($_POST['email'] ?? ''),
                'message' => sanitize($_POST['message'])
            ]);
            $submitted = true;
        }
    }
    ?>
    
    <div class="public-container">
        <div class="public-card">
            <svg class="public-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
            
            <h1>Entbannung beantragen</h1>
            
            <?php if ($submitted): ?>
                <div class="alert alert-success mt-4">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    <span>Ihr Antrag wurde eingereicht. Ein Administrator wird ihn prüfen.</span>
                </div>
                
                <a href="/" class="btn btn-secondary mt-4">Zurück zur Startseite</a>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="alert alert-error mt-4">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                
                <p class="text-muted mt-2">Ihre IP: <span class="ip-display"><?= htmlspecialchars($security->getClientIP()) ?></span></p>
                
                <form method="POST" class="mt-4" style="text-align: left;">
                    <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                    
                    <div class="form-group">
                        <label class="form-label" for="email">E-Mail (optional)</label>
                        <input type="email" id="email" name="email" class="form-input" placeholder="Für Rückmeldungen">
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label" for="message">Nachricht *</label>
                        <textarea id="message" name="message" class="form-textarea" rows="4" placeholder="Bitte erklären Sie, warum Ihre Sperre aufgehoben werden sollte..." required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        Antrag absenden
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
