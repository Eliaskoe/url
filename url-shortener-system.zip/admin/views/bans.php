<?php
$page_title = 'Ban-Verwaltung';
require BASE_PATH . '/admin/includes/header.php';

$db = new Database();
$success = false;
$error = false;

// Ban hinzufügen/entfernen
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'add_ban') {
        $ip = trim($_POST['ip']);
        $reason = trim($_POST['reason']);
        $duration = !empty($_POST['duration']) ? intval($_POST['duration']) * 3600 : null;
        
        if (empty($ip)) {
            $error = 'IP-Adresse ist erforderlich';
        } else {
            $db->addBan($ip, $reason, $duration);
            $db->addLog('admin', "IP banned: {$ip}", ['reason' => $reason, 'duration' => $duration]);
            $success = 'IP erfolgreich gebannt';
        }
    } elseif ($_POST['action'] === 'remove_ban') {
        $ip = $_POST['ip'];
        $db->removeBan($ip);
        $db->addLog('admin', "IP unbanned: {$ip}");
        $success = 'Ban erfolgreich entfernt';
    }
}

$bans = $db->getAllBans();
?>

<?php if ($success): ?>
<div class="card" style="background: rgba(16, 185, 129, 0.1); border-color: var(--color-success); margin-bottom: 2rem;">
    <p style="color: var(--color-success); margin: 0; font-weight: 500;"><?php echo htmlspecialchars($success); ?></p>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="card" style="background: rgba(239, 68, 68, 0.1); border-color: var(--color-danger); margin-bottom: 2rem;">
    <p style="color: var(--color-danger); margin: 0; font-weight: 500;"><?php echo htmlspecialchars($error); ?></p>
</div>
<?php endif; ?>

<!-- Add Ban Form -->
<div class="card mb-4">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">IP bannen</h2>
    
    <form method="POST" class="grid grid-2">
        <input type="hidden" name="action" value="add_ban">
        
        <div class="form-group">
            <label class="form-label">IP-Adresse</label>
            <input type="text" name="ip" class="form-input" required placeholder="192.168.1.1" pattern="^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$">
        </div>
        
        <div class="form-group">
            <label class="form-label">Dauer (Stunden, leer = permanent)</label>
            <input type="number" name="duration" class="form-input" placeholder="24" min="1">
        </div>
        
        <div class="form-group" style="grid-column: 1 / -1;">
            <label class="form-label">Grund</label>
            <textarea name="reason" class="form-textarea" placeholder="Grund für den Ban..."></textarea>
        </div>
        
        <div style="grid-column: 1 / -1;">
            <button type="submit" class="btn btn-danger">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/>
                </svg>
                IP bannen
            </button>
        </div>
    </form>
</div>

<!-- Bans Table -->
<div class="card">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">
        Gebannte IPs (<?php echo count($bans); ?>)
    </h2>
    
    <?php if (empty($bans)): ?>
        <div style="text-align: center; padding: 3rem; color: var(--color-text-muted);">
            <p>Keine gebannten IPs vorhanden</p>
        </div>
    <?php else: ?>
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>IP-Adresse</th>
                        <th>Grund</th>
                        <th>Gebannt am</th>
                        <th>Läuft ab</th>
                        <th>Status</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bans as $ban): ?>
                        <?php
                        $is_expired = $ban['expires_at'] && strtotime($ban['expires_at']) < time();
                        $is_permanent = empty($ban['expires_at']);
                        ?>
                        <tr>
                            <td>
                                <code style="color: var(--color-danger); font-weight: 600;">
                                    <?php echo htmlspecialchars($ban['ip']); ?>
                                </code>
                            </td>
                            <td class="text-muted">
                                <?php echo htmlspecialchars($ban['reason']) ?: '-'; ?>
                            </td>
                            <td class="text-muted" style="font-size: 0.875rem;">
                                <?php echo date('d.m.Y H:i', strtotime($ban['banned_at'])); ?>
                            </td>
                            <td class="text-muted" style="font-size: 0.875rem;">
                                <?php 
                                if ($is_permanent) {
                                    echo '<span class="badge badge-danger">Permanent</span>';
                                } else {
                                    echo date('d.m.Y H:i', strtotime($ban['expires_at']));
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($is_expired): ?>
                                    <span class="badge badge-warning">Abgelaufen</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">Aktiv</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Ban wirklich entfernen?')">
                                    <input type="hidden" name="action" value="remove_ban">
                                    <input type="hidden" name="ip" value="<?php echo htmlspecialchars($ban['ip']); ?>">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        Entbannen
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require BASE_PATH . '/admin/includes/footer.php'; ?>
