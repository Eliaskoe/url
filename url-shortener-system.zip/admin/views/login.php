<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card card-elevated" style="max-width: 450px; margin: 8rem auto;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="width: 80px; height: 80px; margin: 0 auto 1rem; background: linear-gradient(135deg, var(--color-blue-dark), var(--color-blue-medium)); border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 40px; height: 40px; fill: white;" viewBox="0 0 20 20">
                        <path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5.002 5.002 0 0010 2z"/>
                    </svg>
                </div>
                <h1 style="color: var(--color-blue-pastel); margin-bottom: 0.5rem; font-size: 1.75rem;">Admin-Bereich</h1>
                <p class="text-muted">Melden Sie sich an, um fortzufahren</p>
            </div>
            
            <?php if (!empty($error)): ?>
                <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem; text-align: center;">
                    <p style="color: var(--color-danger); font-weight: 500;">
                        <?php echo htmlspecialchars($error); ?>
                    </p>
                </div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label class="form-label">Passwort</label>
                    <input type="password" name="password" class="form-input" required autofocus placeholder="Ihr Admin-Passwort">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
                    </svg>
                    Anmelden
                </button>
            </form>
            
            <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--color-border); text-align: center;">
                <a href="/" style="color: var(--color-blue-light); text-decoration: none; font-size: 0.875rem;">
                    Zurück zur Startseite
                </a>
            </div>
            
            <div style="margin-top: 1.5rem; background: var(--color-bg-tertiary); border-radius: 8px; padding: 1rem;">
                <p style="font-size: 0.75rem; color: var(--color-text-muted); text-align: center; margin: 0;">
                    Standard-Passwort: <code style="color: var(--color-blue-light);">admin123</code>
                    <br>
                    <span style="color: var(--color-warning);">Bitte nach dem ersten Login ändern!</span>
                </p>
            </div>
        </div>
    </div>
</body>
</html>
