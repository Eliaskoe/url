<?php
$page_title = 'Nachrichten';
require BASE_PATH . '/admin/includes/header.php';

$db = new Database();
$success = false;

// Message verarbeiten
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['action'] === 'reply') {
        $message_id = $_POST['message_id'];
        $reply = $_POST['reply'];
        
        $db->updateMessage($message_id, [
            'status' => 'replied',
            'admin_reply' => $reply,
            'replied_at' => date('Y-m-d H:i:s')
        ]);
        $db->addLog('admin', "Replied to message: {$message_id}");
        $success = 'Antwort gespeichert';
    } elseif ($_POST['action'] === 'approve_unban') {
        $message_id = $_POST['message_id'];
        $message = $db->getAllMessages()[$message_id];
        
        $db->removeBan($message['ip']);
        $db->updateMessage($message_id, [
            'status' => 'approved'
        ]);
        $db->addLog('admin', "Approved unban request for IP: {$message['ip']}");
        $success = 'Entbannung genehmigt';
    } elseif ($_POST['action'] === 'reject') {
        $message_id = $_POST['message_id'];
        $db->updateMessage($message_id, [
            'status' => 'rejected'
        ]);
        $db->addLog('admin', "Rejected message: {$message_id}");
        $success = 'Anfrage abgelehnt';
    }
}

$messages = array_reverse($db->getAllMessages());
?>

<?php if ($success): ?>
<div class="card" style="background: rgba(16, 185, 129, 0.1); border-color: var(--color-success); margin-bottom: 2rem;">
    <p style="color: var(--color-success); margin: 0; font-weight: 500;"><?php echo htmlspecialchars($success); ?></p>
</div>
<?php endif; ?>

<div class="card">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">
        Nachrichten (<?php echo count($messages); ?>)
    </h2>
    
    <?php if (empty($messages)): ?>
        <div style="text-align: center; padding: 3rem; color: var(--color-text-muted);">
            <p>Keine Nachrichten vorhanden</p>
        </div>
    <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 1.5rem;">
            <?php foreach ($messages as $message): ?>
                <div style="padding: 1.5rem; background: var(--color-bg-tertiary); border-radius: 12px; border-left: 4px solid <?php
                    echo $message['status'] === 'pending' ? 'var(--color-warning)' : 
                         ($message['status'] === 'approved' ? 'var(--color-success)' : 
                          ($message['status'] === 'rejected' ? 'var(--color-danger)' : 'var(--color-blue-medium)'));
                ?>;">
                    <!-- Header -->
                    <div class="flex justify-between items-center mb-3">
                        <div class="flex items-center gap-2">
                            <span class="badge <?php
                                echo $message['status'] === 'pending' ? 'badge-warning' : 
                                     ($message['status'] === 'approved' ? 'badge-success' : 
                                      ($message['status'] === 'rejected' ? 'badge-danger' : 'badge-blue'));
                            ?>">
                                <?php 
                                echo $message['status'] === 'pending' ? 'Ausstehend' : 
                                     ($message['status'] === 'approved' ? 'Genehmigt' : 
                                      ($message['status'] === 'rejected' ? 'Abgelehnt' : 'Beantwortet'));
                                ?>
                            </span>
                            <span class="badge badge-blue"><?php echo strtoupper($message['type']); ?></span>
                        </div>
                        <span class="text-muted" style="font-size: 0.875rem;">
                            <?php echo date('d.m.Y H:i', strtotime($message['created_at'])); ?>
                        </span>
                    </div>
                    
                    <!-- Content -->
                    <div class="grid grid-2 mb-3">
                        <div>
                            <p style="font-size: 0.875rem; color: var(--color-text-muted); margin-bottom: 0.25rem;">E-Mail:</p>
                            <p style="color: var(--color-text-primary); font-weight: 500;"><?php echo htmlspecialchars($message['email']); ?></p>
                        </div>
                        <div>
                            <p style="font-size: 0.875rem; color: var(--color-text-muted); margin-bottom: 0.25rem;">IP-Adresse:</p>
                            <code style="color: var(--color-danger); font-weight: 600;"><?php echo htmlspecialchars($message['ip']); ?></code>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <p style="font-size: 0.875rem; color: var(--color-text-muted); margin-bottom: 0.5rem;">Nachricht:</p>
                        <div style="padding: 1rem; background: var(--color-bg-secondary); border-radius: 8px;">
                            <p style="color: var(--color-text-primary); margin: 0; line-height: 1.6;">
                                <?php echo nl2br(htmlspecialchars($message['reason'])); ?>
                            </p>
                        </div>
                    </div>
                    
                    <?php if ($message['status'] === 'replied' && !empty($message['admin_reply'])): ?>
                        <div class="mb-3">
                            <p style="font-size: 0.875rem; color: var(--color-text-muted); margin-bottom: 0.5rem;">Admin-Antwort:</p>
                            <div style="padding: 1rem; background: rgba(59, 130, 246, 0.1); border-radius: 8px; border-left: 3px solid var(--color-blue-medium);">
                                <p style="color: var(--color-text-primary); margin: 0; line-height: 1.6;">
                                    <?php echo nl2br(htmlspecialchars($message['admin_reply'])); ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Visitor Data -->
                    <?php if (!empty($message['visitor_data'])): ?>
                        <details style="background: var(--color-bg-secondary); border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                            <summary style="cursor: pointer; color: var(--color-blue-light); font-size: 0.875rem; font-weight: 500;">
                                Besucher-Daten anzeigen
                            </summary>
                            <div style="margin-top: 1rem; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; font-size: 0.875rem;">
                                <div>
                                    <p class="text-muted">User-Agent:</p>
                                    <p style="color: var(--color-text-primary); word-break: break-all;">
                                        <?php echo htmlspecialchars($message['visitor_data']['user_agent'] ?? 'Unknown'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-muted">Referer:</p>
                                    <p style="color: var(--color-text-primary);">
                                        <?php echo htmlspecialchars($message['visitor_data']['referer'] ?? '-'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-muted">Country:</p>
                                    <p style="color: var(--color-text-primary);">
                                        <?php echo htmlspecialchars($message['visitor_data']['country'] ?? 'Unknown'); ?>
                                    </p>
                                </div>
                                <div>
                                    <p class="text-muted">Proxy/VPN:</p>
                                    <span class="badge <?php echo ($message['visitor_data']['is_proxy'] ?? false) ? 'badge-warning' : 'badge-success'; ?>">
                                        <?php echo ($message['visitor_data']['is_proxy'] ?? false) ? 'Ja' : 'Nein'; ?>
                                    </span>
                                </div>
                            </div>
                        </details>
                    <?php endif; ?>
                    
                    <!-- Actions -->
                    <?php if ($message['status'] === 'pending'): ?>
                        <div class="flex gap-2">
                            <button onclick="showReplyForm('<?php echo $message['id']; ?>')" class="btn btn-secondary btn-sm">
                                Antworten
                            </button>
                            <?php if ($message['type'] === 'unban_request'): ?>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="action" value="approve_unban">
                                    <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                    <button type="submit" class="btn btn-success btn-sm">
                                        Entbannen & Genehmigen
                                    </button>
                                </form>
                            <?php endif; ?>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="action" value="reject">
                                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                <button type="submit" class="btn btn-danger btn-sm">
                                    Ablehnen
                                </button>
                            </form>
                        </div>
                        
                        <!-- Reply Form (hidden) -->
                        <form method="POST" id="replyForm_<?php echo $message['id']; ?>" style="display: none; margin-top: 1rem;">
                            <input type="hidden" name="action" value="reply">
                            <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                            <div class="form-group">
                                <label class="form-label">Ihre Antwort</label>
                                <textarea name="reply" class="form-textarea" required placeholder="Antwort an den Nutzer..."></textarea>
                            </div>
                            <div class="flex gap-2">
                                <button type="button" onclick="hideReplyForm('<?php echo $message['id']; ?>')" class="btn btn-secondary btn-sm">
                                    Abbrechen
                                </button>
                                <button type="submit" class="btn btn-primary btn-sm">
                                    Antwort senden
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function showReplyForm(id) {
    document.getElementById('replyForm_' + id).style.display = 'block';
}
function hideReplyForm(id) {
    document.getElementById('replyForm_' + id).style.display = 'none';
}
</script>

<?php require BASE_PATH . '/admin/includes/footer.php'; ?>
