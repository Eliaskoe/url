<aside class="sidebar">
    <div class="sidebar-logo">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
            <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
        </svg>
        <span>URL Shortener</span>
    </div>
    
    <nav class="sidebar-nav">
        <div class="nav-section">Übersicht</div>
        
        <a href="<?= ADMIN_PATH ?>" class="nav-item <?= $adminPath === 'dashboard' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
            Dashboard
        </a>
        
        <?php if ($auth->hasPermission('view_links')): ?>
        <a href="<?= ADMIN_PATH ?>/links" class="nav-item <?= $adminPath === 'links' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
            Links
        </a>
        <?php endif; ?>
        
        <div class="nav-section">Monitoring</div>
        
        <?php if ($auth->hasPermission('view_visitors')): ?>
        <a href="<?= ADMIN_PATH ?>/visitors" class="nav-item <?= $adminPath === 'visitors' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
            Besucher
        </a>
        <?php endif; ?>
        
        <?php if ($auth->hasPermission('view_security')): ?>
        <a href="<?= ADMIN_PATH ?>/security" class="nav-item <?= $adminPath === 'security' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Security Logs
        </a>
        <?php endif; ?>
        
        <div class="nav-section">Sicherheit</div>
        
        <?php if ($auth->hasPermission('view_bans')): ?>
        <a href="<?= ADMIN_PATH ?>/bans" class="nav-item <?= $adminPath === 'bans' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
            Bans
        </a>
        <?php endif; ?>
        
        <?php if ($auth->hasPermission('manage_unban_requests')): ?>
        <a href="<?= ADMIN_PATH ?>/unban-requests" class="nav-item <?= $adminPath === 'unban-requests' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            Entbann-Anträge
        </a>
        <?php endif; ?>
        
        <div class="nav-section">Verwaltung</div>
        
        <?php if ($auth->hasPermission('manage_users')): ?>
        <a href="<?= ADMIN_PATH ?>/users" class="nav-item <?= $adminPath === 'users' ? 'active' : '' ?>">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></svg>
            Benutzer
        </a>
        <?php endif; ?>
        
        <div class="nav-section" style="margin-top: auto;"></div>
        
        <a href="<?= ADMIN_PATH ?>/logout" class="nav-item">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
            Abmelden
        </a>
    </nav>
    
    <div style="margin-top: auto; padding-top: 1rem; border-top: 1px solid var(--border-color);">
        <div class="text-small text-muted">Angemeldet als</div>
        <div class="text-small" style="color: var(--accent-primary);"><?= htmlspecialchars($_SESSION['username']) ?></div>
        <div class="badge badge-<?= $_SESSION['role'] === 'admin' ? 'success' : 'info' ?> mt-1">
            <?= $_SESSION['role'] === 'admin' ? 'Administrator' : 'Benutzer' ?>
        </div>
    </div>
</aside>
