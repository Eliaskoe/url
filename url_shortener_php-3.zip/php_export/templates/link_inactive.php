<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link inaktiv - URL Shortener</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="public-container">
        <div class="public-card">
            <svg class="public-icon warning" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
            
            <h1>Link deaktiviert</h1>
            <p class="text-muted mt-2">Dieser Link ist derzeit nicht verfügbar</p>
            
            <p class="mt-4 text-secondary">
                Der Kurzlink wurde vom Administrator deaktiviert oder gesperrt.
            </p>
            
            <a href="/" class="btn btn-secondary mt-4">
                Zur Startseite
            </a>
        </div>
    </div>
</body>
</html>
