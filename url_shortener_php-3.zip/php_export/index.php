<?php
/**
 * URL Shortener - Front Controller
 * Einstiegspunkt für alle Anfragen
 * 
 * @author EDK
 * @domain url.edk.codes
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Basis-Konstanten
define('BASE_PATH', __DIR__);
define('DATA_PATH', BASE_PATH . '/data');
define('INCLUDES_PATH', BASE_PATH . '/includes');

// Includes laden
require_once INCLUDES_PATH . '/config.php';
require_once INCLUDES_PATH . '/functions.php';
require_once INCLUDES_PATH . '/security.php';
require_once INCLUDES_PATH . '/auth.php';
require_once INCLUDES_PATH . '/storage.php';

// Security Check - Cookie Manipulation
$security = new Security();
$security->checkCookieIntegrity();
$security->logVisitor();

// IP Ban Check
$storage = new Storage();
$clientIP = $security->getClientIP();

if ($storage->isIPBanned($clientIP)) {
    include BASE_PATH . '/templates/banned.php';
    exit;
}

// Router
$requestUri = $_SERVER['REQUEST_URI'];
$path = parse_url($requestUri, PHP_URL_PATH);
$path = trim($path, '/');

// Admin-Bereich
if (strpos($path, 'cadmin') === 0 || strpos($path, 'admin') === 0) {
    require_once BASE_PATH . '/admin/index.php';
    exit;
}

// Entbann-Antrag
if ($path === 'unban-request') {
    include BASE_PATH . '/templates/unban_request.php';
    exit;
}

// API Endpoints
if (strpos($path, 'api/') === 0) {
    require_once BASE_PATH . '/includes/api.php';
    exit;
}

// Kurzlink-Weiterleitung
if (!empty($path) && $path !== 'index.php') {
    $link = $storage->getLinkBySlug($path);
    
    if ($link) {
        // Link gefunden
        if ($link['status'] !== 'active') {
            include BASE_PATH . '/templates/link_inactive.php';
            exit;
        }
        
        // Ablaufzeit prüfen
        if (!empty($link['expires_at']) && strtotime($link['expires_at']) < time()) {
            include BASE_PATH . '/templates/link_expired.php';
            exit;
        }
        
        // Klick loggen
        $storage->logClick($link['id'], $clientIP, $_SERVER['HTTP_USER_AGENT'] ?? '', $_SERVER['HTTP_REFERER'] ?? '');
        
        // Vorschaltseite?
        if (!empty($link['warning_page'])) {
            $_SESSION['redirect_target'] = $link['target_url'];
            $_SESSION['redirect_slug'] = $path;
            include BASE_PATH . '/templates/warning_page.php';
            exit;
        }
        
        // Weiterleitung
        header('Location: ' . $link['target_url'], true, 302);
        exit;
    } else {
        // Link nicht gefunden
        http_response_code(404);
        include BASE_PATH . '/templates/404.php';
        exit;
    }
}

// Startseite
include BASE_PATH . '/templates/home.php';
