<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Links - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header flex justify-between items-center">
                <div>
                    <h1 class="page-title">Links verwalten</h1>
                    <p class="page-subtitle"><?= count($links) ?> Links insgesamt</p>
                </div>
                <?php if ($auth->hasPermission('manage_links')): ?>
                <button class="btn btn-primary" onclick="openModal('createModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Neuer Link
                </button>
                <?php endif; ?>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Slug</th>
                            <th>Ziel-URL</th>
                            <th>Status</th>
                            <th>Klicks</th>
                            <th>Erstellt</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($links)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted" style="padding: 2rem;">Keine Links vorhanden</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach (array_reverse($links) as $link): ?>
                            <tr>
                                <td>
                                    <a href="<?= BASE_URL ?>/<?= htmlspecialchars($link['slug']) ?>" target="_blank" class="monospace">
                                        /<?= htmlspecialchars($link['slug']) ?>
                                    </a>
                                    <?php if (!empty($link['title'])): ?>
                                        <div class="text-xs text-muted"><?= htmlspecialchars($link['title']) ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="text-small text-muted" style="max-width: 300px; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        <?= htmlspecialchars($link['target_url']) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $statusClass = match($link['status']) {
                                        'active' => 'success',
                                        'inactive' => 'secondary',
                                        'banned' => 'danger',
                                        default => 'secondary'
                                    };
                                    $statusLabel = match($link['status']) {
                                        'active' => 'Aktiv',
                                        'inactive' => 'Inaktiv',
                                        'banned' => 'Gesperrt',
                                        default => $link['status']
                                    };
                                    ?>
                                    <span class="badge badge-<?= $statusClass ?>"><?= $statusLabel ?></span>
                                    <?php if (!empty($link['warning_page'])): ?>
                                        <span class="badge badge-warning">Warnung</span>
                                    <?php endif; ?>
                                    <?php if (!empty($link['expires_at'])): ?>
                                        <span class="badge badge-info" title="Läuft ab: <?= $link['expires_at'] ?>">Timer</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <strong><?= $link['clicks'] ?? 0 ?></strong>
                                </td>
                                <td class="text-small text-muted">
                                    <?= formatDateTime($link['created_at']) ?>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <?php if ($auth->hasPermission('manage_links')): ?>
                                        <button class="btn btn-secondary btn-sm btn-icon" onclick="editLink('<?= htmlspecialchars(json_encode($link)) ?>')" title="Bearbeiten">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                        </button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Link wirklich löschen?');">
                                            <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="link_id" value="<?= $link['id'] ?>">
                                            <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Löschen">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <!-- Create Modal -->
    <div class="modal-overlay" id="createModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Neuen Link erstellen</h3>
                <button class="modal-close" onclick="closeModal('createModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label class="form-label" for="target_url">Ziel-URL *</label>
                    <input type="url" id="target_url" name="target_url" class="form-input" placeholder="https://example.com" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="slug">Slug (optional)</label>
                    <input type="text" id="slug" name="slug" class="form-input" placeholder="Automatisch generieren">
                    <small class="text-muted">Leer lassen für automatische Generierung</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="title">Titel (optional)</label>
                    <input type="text" id="title" name="title" class="form-input" placeholder="Link-Beschreibung">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="expires_at">Ablaufdatum (optional)</label>
                    <input type="datetime-local" id="expires_at" name="expires_at" class="form-input">
                </div>
                
                <div class="form-group">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" name="warning_page">
                        <span>Vorschaltseite anzeigen</span>
                    </label>
                </div>
                
                <div class="flex gap-2 justify-between">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Abbrechen</button>
                    <button type="submit" class="btn btn-primary">Link erstellen</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal-overlay" id="editModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Link bearbeiten</h3>
                <button class="modal-close" onclick="closeModal('editModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            
            <form method="POST" id="editForm">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="link_id" id="edit_link_id">
                
                <div class="form-group">
                    <label class="form-label">Slug</label>
                    <input type="text" id="edit_slug" class="form-input" disabled>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_target_url">Ziel-URL *</label>
                    <input type="url" id="edit_target_url" name="target_url" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_title">Titel</label>
                    <input type="text" id="edit_title" name="title" class="form-input">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_status">Status</label>
                    <select id="edit_status" name="status" class="form-select">
                        <option value="active">Aktiv</option>
                        <option value="inactive">Inaktiv</option>
                        <option value="banned">Gesperrt</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_expires_at">Ablaufdatum</label>
                    <input type="datetime-local" id="edit_expires_at" name="expires_at" class="form-input">
                </div>
                
                <div class="form-group">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" name="warning_page" id="edit_warning_page">
                        <span>Vorschaltseite anzeigen</span>
                    </label>
                </div>
                
                <div class="flex gap-2 justify-between">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Abbrechen</button>
                    <button type="submit" class="btn btn-primary">Speichern</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function openModal(id) {
            document.getElementById(id).classList.add('active');
        }
        
        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }
        
        function editLink(linkJson) {
            const link = JSON.parse(linkJson);
            document.getElementById('edit_link_id').value = link.id;
            document.getElementById('edit_slug').value = link.slug;
            document.getElementById('edit_target_url').value = link.target_url;
            document.getElementById('edit_title').value = link.title || '';
            document.getElementById('edit_status').value = link.status;
            document.getElementById('edit_warning_page').checked = link.warning_page;
            
            if (link.expires_at) {
                document.getElementById('edit_expires_at').value = link.expires_at.replace(' ', 'T').slice(0, 16);
            } else {
                document.getElementById('edit_expires_at').value = '';
            }
            
            openModal('editModal');
        }
        
        // Close modal on escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
            }
        });
        
        // Close modal on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
