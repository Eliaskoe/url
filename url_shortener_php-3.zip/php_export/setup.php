<?php
/**
 * Setup-Script für ersten Admin-Benutzer
 * Führe dieses Script einmal aus, um den Admin zu erstellen
 * 
 * Aufruf: php setup.php
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/storage.php';

echo "URL Shortener - Admin Setup\n";
echo "===========================\n\n";

$storage = new Storage();

// Prüfen ob schon Benutzer existieren
$users = $storage->getUsers();

if (!empty($users)) {
    echo "Es existieren bereits Benutzer!\n";
    echo "Möchten Sie trotzdem einen neuen Admin erstellen? (j/n): ";
    $handle = fopen("php://stdin", "r");
    $line = fgets($handle);
    if (trim($line) !== 'j') {
        echo "Abgebrochen.\n";
        exit;
    }
    fclose($handle);
}

// Admin-Benutzer erstellen
$username = 'Elias061010';
$password = 'Elias061010';

// Passwort hashen
$hashedPassword = password_hash($password, PASSWORD_ARGON2ID);

$admin = [
    'id' => generateUUID(),
    'username' => $username,
    'password' => $hashedPassword,
    'role' => 'admin',
    'permissions' => [],
    'created_at' => date('Y-m-d H:i:s'),
    'last_login' => null,
    'active' => true
];

// Direkt in users.json schreiben
$usersFile = DATA_PATH . '/users.json';
$users = file_exists($usersFile) ? json_decode(file_get_contents($usersFile), true) : [];

// Prüfen ob Benutzer schon existiert
$exists = false;
foreach ($users as $user) {
    if ($user['username'] === $username) {
        $exists = true;
        break;
    }
}

if ($exists) {
    echo "Benutzer '$username' existiert bereits!\n";
} else {
    $users[] = $admin;
    file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo "Admin-Benutzer erstellt!\n\n";
    echo "Zugangsdaten:\n";
    echo "  Benutzername: $username\n";
    echo "  Passwort:     $password\n\n";
    echo "WICHTIG: Ändern Sie das Passwort nach dem ersten Login!\n";
}

echo "\nAdmin-Panel: " . BASE_URL . ADMIN_PATH . "\n";
