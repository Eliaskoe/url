<?php
/**
 * Security-Klasse
 * Cookie-Manipulation, IP-Erkennung, Logging
 */

class Security {
    private $storage;
    
    public function __construct() {
        $this->storage = new Storage();
    }
    
    /**
     * Client-IP ermitteln
     */
    public function getClientIP() {
        $headers = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR'
        ];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Cookie-Hash generieren
     */
    public function generateCookieHash($data) {
        return hash_hmac('sha256', json_encode($data), COOKIE_SECRET);
    }
    
    /**
     * Sicheren Cookie setzen
     */
    public function setSecureCookie($name, $data) {
        $hash = $this->generateCookieHash($data);
        $cookieValue = base64_encode(json_encode([
            'data' => $data,
            'hash' => $hash,
            'timestamp' => time()
        ]));
        
        setcookie($name, $cookieValue, [
            'expires' => time() + COOKIE_LIFETIME,
            'path' => '/',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
    }
    
    /**
     * Sicheren Cookie lesen
     */
    public function getSecureCookie($name) {
        if (!isset($_COOKIE[$name])) {
            return null;
        }
        
        $decoded = json_decode(base64_decode($_COOKIE[$name]), true);
        
        if (!$decoded || !isset($decoded['data']) || !isset($decoded['hash'])) {
            return null;
        }
        
        $expectedHash = $this->generateCookieHash($decoded['data']);
        
        if (!hash_equals($expectedHash, $decoded['hash'])) {
            return false; // Manipulation erkannt!
        }
        
        return $decoded['data'];
    }
    
    /**
     * Cookie-Integrität prüfen
     */
    public function checkCookieIntegrity() {
        $checkCookie = $this->getSecureCookie(BAN_COOKIE_NAME);
        
        if ($checkCookie === false) {
            // Cookie wurde manipuliert!
            $this->logSecurityEvent('cookie_manipulation', [
                'ip' => $this->getClientIP(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
                'cookie_name' => BAN_COOKIE_NAME
            ]);
            
            // IP bannen
            $this->storage->banIP($this->getClientIP(), 'Cookie-Manipulation erkannt', 86400 * 7);
            
            // Neuen Cookie setzen
            $this->setSecureCookie(BAN_COOKIE_NAME, ['banned' => true, 'reason' => 'manipulation']);
            
            return false;
        }
        
        // Ersten Cookie setzen wenn nicht vorhanden
        if ($checkCookie === null) {
            $this->setSecureCookie(BAN_COOKIE_NAME, [
                'visitor_id' => generateUUID(),
                'first_visit' => date('Y-m-d H:i:s'),
                'banned' => false
            ]);
        }
        
        return true;
    }
    
    /**
     * Besucher loggen
     */
    public function logVisitor() {
        if (!LOG_VISITORS) return;
        
        $visitorData = [
            'id' => generateUUID(),
            'ip' => $this->getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
            'request_uri' => $_SERVER['REQUEST_URI'] ?? '/',
            'session_id' => session_id(),
            'timestamp' => date('Y-m-d H:i:s'),
            'cookies' => $this->getSafeCookieInfo()
        ];
        
        $this->storage->saveVisitorLog($visitorData);
    }
    
    /**
     * Sichere Cookie-Info für Logging
     */
    private function getSafeCookieInfo() {
        $cookies = [];
        foreach ($_COOKIE as $name => $value) {
            $cookies[$name] = strlen($value) > 50 ? substr($value, 0, 50) . '...' : $value;
        }
        return $cookies;
    }
    
    /**
     * Security-Event loggen
     */
    public function logSecurityEvent($type, $data = []) {
        if (!LOG_SECURITY_EVENTS) return;
        
        $event = [
            'id' => generateUUID(),
            'type' => $type,
            'data' => $data,
            'ip' => $this->getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'timestamp' => date('Y-m-d H:i:s'),
            'severity' => $this->getEventSeverity($type)
        ];
        
        $this->storage->saveSecurityLog($event);
    }
    
    /**
     * Event-Schweregrad ermitteln
     */
    private function getEventSeverity($type) {
        $severities = [
            'cookie_manipulation' => 'critical',
            'login_failed' => 'warning',
            'login_success' => 'info',
            'ip_banned' => 'warning',
            'ip_unbanned' => 'info',
            'brute_force' => 'critical',
            'suspicious_activity' => 'warning'
        ];
        
        return $severities[$type] ?? 'info';
    }
    
    /**
     * VPN/Proxy erkennen (einfache Heuristik)
     */
    public function detectProxy() {
        $proxyHeaders = [
            'HTTP_VIA',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_FORWARDED',
            'HTTP_CLIENT_IP',
            'HTTP_FORWARDED_FOR_IP',
            'VIA',
            'X_FORWARDED_FOR',
            'FORWARDED_FOR',
            'X_FORWARDED',
            'FORWARDED',
            'CLIENT_IP',
            'FORWARDED_FOR_IP',
            'HTTP_PROXY_CONNECTION'
        ];
        
        foreach ($proxyHeaders as $header) {
            if (!empty($_SERVER[$header])) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * User-Agent parsen
     */
    public function parseUserAgent($ua) {
        $browser = 'Unknown';
        $os = 'Unknown';
        
        // Browser erkennen
        if (preg_match('/Firefox\/([0-9.]+)/', $ua, $m)) {
            $browser = 'Firefox ' . $m[1];
        } elseif (preg_match('/Chrome\/([0-9.]+)/', $ua, $m)) {
            $browser = 'Chrome ' . $m[1];
        } elseif (preg_match('/Safari\/([0-9.]+)/', $ua, $m)) {
            $browser = 'Safari ' . $m[1];
        } elseif (preg_match('/Edge\/([0-9.]+)/', $ua, $m)) {
            $browser = 'Edge ' . $m[1];
        } elseif (preg_match('/MSIE ([0-9.]+)/', $ua, $m)) {
            $browser = 'IE ' . $m[1];
        }
        
        // OS erkennen
        if (preg_match('/Windows NT ([0-9.]+)/', $ua, $m)) {
            $versions = ['10.0' => '10', '6.3' => '8.1', '6.2' => '8', '6.1' => '7'];
            $os = 'Windows ' . ($versions[$m[1]] ?? $m[1]);
        } elseif (preg_match('/Mac OS X ([0-9_]+)/', $ua, $m)) {
            $os = 'macOS ' . str_replace('_', '.', $m[1]);
        } elseif (preg_match('/Linux/', $ua)) {
            $os = 'Linux';
        } elseif (preg_match('/Android ([0-9.]+)/', $ua, $m)) {
            $os = 'Android ' . $m[1];
        } elseif (preg_match('/iPhone OS ([0-9_]+)/', $ua, $m)) {
            $os = 'iOS ' . str_replace('_', '.', $m[1]);
        }
        
        return ['browser' => $browser, 'os' => $os];
    }
}
