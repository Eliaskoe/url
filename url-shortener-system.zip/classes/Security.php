<?php
/**
 * Security Klasse
 * Cookie-Manipulation, IP-Tracking, Ban-Verwaltung
 */
class Security {
    private $db;
    private $cookie_name = 'edk_tracking';
    private $secret_key = 'change-this-secret-key-in-production';
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function getVisitorData() {
        return [
            'ip' => $this->getClientIP(),
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown',
            'referer' => $_SERVER['HTTP_REFERER'] ?? '',
            'timestamp' => date('Y-m-d H:i:s'),
            'country' => $this->getCountryFromIP(),
            'is_proxy' => $this->isProxy()
        ];
    }
    
    private function getClientIP() {
        $ip_keys = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                return $ip;
            }
        }
        return '0.0.0.0';
    }
    
    private function getCountryFromIP() {
        // Vereinfachte IP-Geolocation (in Produktion: externe API verwenden)
        return 'Unknown';
    }
    
    private function isProxy() {
        // Vereinfachte Proxy-Erkennung
        $proxy_headers = ['HTTP_VIA', 'HTTP_X_FORWARDED_FOR', 'HTTP_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_FORWARDED', 'HTTP_CLIENT_IP', 'HTTP_FORWARDED_FOR_IP', 'VIA', 'X_FORWARDED_FOR', 'FORWARDED_FOR', 'X_FORWARDED', 'FORWARDED', 'CLIENT_IP', 'FORWARDED_FOR_IP', 'HTTP_PROXY_CONNECTION'];
        
        foreach ($proxy_headers as $header) {
            if (!empty($_SERVER[$header])) {
                return true;
            }
        }
        return false;
    }
    
    public function setTrackingCookie($slug) {
        $value = $slug . '|' . time();
        $hash = hash_hmac('sha256', $value, $this->secret_key);
        $cookie_value = base64_encode($value . '|' . $hash);
        
        setcookie($this->cookie_name, $cookie_value, time() + (86400 * 30), '/', '', false, true);
    }
    
    public function verifyTrackingCookie() {
        if (!isset($_COOKIE[$this->cookie_name])) {
            return true; // Kein Cookie = OK
        }
        
        $cookie_value = base64_decode($_COOKIE[$this->cookie_name]);
        $parts = explode('|', $cookie_value);
        
        if (count($parts) !== 3) {
            return false; // Manipuliert
        }
        
        list($slug, $timestamp, $provided_hash) = $parts;
        $expected_hash = hash_hmac('sha256', $slug . '|' . $timestamp, $this->secret_key);
        
        if (!hash_equals($expected_hash, $provided_hash)) {
            // Cookie wurde manipuliert!
            $this->handleCookieManipulation();
            return false;
        }
        
        return true;
    }
    
    private function handleCookieManipulation() {
        $visitor_data = $this->getVisitorData();
        
        // Sofort bannen
        $this->db->addBan($visitor_data['ip'], 'Cookie Manipulation detected', 86400); // 24h
        
        // Log-Eintrag
        $this->db->addLog('security', 'Cookie Manipulation detected', $visitor_data);
    }
    
    public function isBanned($visitor_data) {
        // Cookie-Verifikation
        if (!$this->verifyTrackingCookie()) {
            return true;
        }
        
        return $this->db->isBanned($visitor_data['ip']);
    }
}
