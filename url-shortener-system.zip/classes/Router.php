<?php
/**
 * Router Klasse
 * Verarbeitet Short URLs und leitet weiter
 */
class Router {
    private $db;
    private $security;
    private $logger;
    
    public function __construct() {
        $this->db = new Database();
        $this->security = new Security();
        $this->logger = new Logger();
    }
    
    public function handleShortUrl($slug) {
        // Security Check
        $visitor_data = $this->security->getVisitorData();
        
        // Ban-Status prüfen
        if ($this->security->isBanned($visitor_data)) {
            header('Location: /unban');
            exit;
        }
        
        // Link aus Datenbank laden
        $link = $this->db->getLinkBySlug($slug);
        
        if (!$link) {
            http_response_code(404);
            require_once BASE_PATH . '/views/404.php';
            exit;
        }
        
        // Link-Status prüfen
        if ($link['status'] !== 'active') {
            http_response_code(410);
            require_once BASE_PATH . '/views/link-disabled.php';
            exit;
        }
        
        // Ablaufzeit prüfen
        if ($link['expires_at'] && strtotime($link['expires_at']) < time()) {
            http_response_code(410);
            require_once BASE_PATH . '/views/link-expired.php';
            exit;
        }
        
        // Visit loggen
        $this->logger->logVisit($slug, $visitor_data);
        
        // Tracking Cookie setzen (Hash-basiert)
        $this->security->setTrackingCookie($slug);
        
        // Vorschaltseite prüfen
        if ($link['show_warning'] === true) {
            $_SESSION['redirect_to'] = $link['target_url'];
            require_once BASE_PATH . '/views/warning.php';
            exit;
        }
        
        // Weiterleitung
        header('Location: ' . $link['target_url'], true, 302);
        exit;
    }
}
