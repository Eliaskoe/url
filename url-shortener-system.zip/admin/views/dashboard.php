<?php
$page_title = 'Dashboard';
require BASE_PATH . '/admin/includes/header.php';

$db = new Database();
$links = $db->getAllLinks();
$logs = $db->getAllLogs();
$bans = $db->getAllBans();
$messages = $db->getAllMessages();

// Statistiken berechnen
$total_links = count($links);
$active_links = count(array_filter($links, fn($l) => $l['status'] === 'active'));
$total_clicks = array_sum(array_column($links, 'clicks'));
$total_bans = count($bans);
$pending_messages = count(array_filter($messages, fn($m) => $m['status'] === 'pending'));

// Letzte Aktivitäten
$recent_logs = array_slice(array_reverse($logs), 0, 10);
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue">
            <svg style="width: 24px; height: 24px; fill: currentColor;" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"/>
            </svg>
        </div>
        <div class="stat-info">
            <div class="stat-label">Gesamt Links</div>
            <div class="stat-value"><?php echo $total_links; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon green">
            <svg style="width: 24px; height: 24px; fill: currentColor;" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
        </div>
        <div class="stat-info">
            <div class="stat-label">Aktive Links</div>
            <div class="stat-value"><?php echo $active_links; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon blue">
            <svg style="width: 24px; height: 24px; fill: currentColor;" viewBox="0 0 20 20">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
                <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
            </svg>
        </div>
        <div class="stat-info">
            <div class="stat-label">Gesamt Klicks</div>
            <div class="stat-value"><?php echo $total_clicks; ?></div>
        </div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon red">
            <svg style="width: 24px; height: 24px; fill: currentColor;" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/>
            </svg>
        </div>
        <div class="stat-info">
            <div class="stat-label">Gebannte IPs</div>
            <div class="stat-value"><?php echo $total_bans; ?></div>
        </div>
    </div>
</div>

<?php if ($pending_messages > 0): ?>
<div class="card" style="background: rgba(245, 158, 11, 0.1); border-color: var(--color-warning); margin-bottom: 2rem;">
    <div class="flex items-center gap-2">
        <svg style="width: 24px; height: 24px; fill: var(--color-warning);" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
        </svg>
        <div>
            <strong style="color: var(--color-warning);">Neue Nachrichten</strong>
            <p style="color: var(--color-text-secondary); font-size: 0.875rem; margin: 0;">
                Sie haben <?php echo $pending_messages; ?> ungelesene Nachricht<?php echo $pending_messages > 1 ? 'en' : ''; ?>
            </p>
        </div>
        <a href="<?php echo ADMIN_PATH; ?>/messages" class="btn btn-secondary" style="margin-left: auto;">
            Ansehen
        </a>
    </div>
</div>
<?php endif; ?>

<div class="grid" style="grid-template-columns: 2fr 1fr; gap: 2rem;">
    <!-- Recent Activity -->
    <div class="card">
        <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">Letzte Aktivitäten</h2>
        
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            <?php foreach ($recent_logs as $log): ?>
                <div style="padding: 1rem; background: var(--color-bg-tertiary); border-radius: 8px; border-left: 3px solid <?php
                    echo $log['type'] === 'security' ? 'var(--color-danger)' : 
                         ($log['type'] === 'admin' ? 'var(--color-blue-medium)' : 
                          ($log['type'] === 'visit' ? 'var(--color-success)' : 'var(--color-text-muted)'));
                ?>;">
                    <div class="flex justify-between items-center mb-1">
                        <span class="badge <?php
                            echo $log['type'] === 'security' ? 'badge-danger' : 
                                 ($log['type'] === 'admin' ? 'badge-blue' : 
                                  ($log['type'] === 'visit' ? 'badge-success' : 'badge-warning'));
                        ?>"><?php echo strtoupper($log['type']); ?></span>
                        <span class="text-muted" style="font-size: 0.75rem;">
                            <?php echo date('d.m.Y H:i', strtotime($log['timestamp'])); ?>
                        </span>
                    </div>
                    <p style="color: var(--color-text-secondary); font-size: 0.875rem; margin: 0;">
                        <?php echo htmlspecialchars($log['message']); ?>
                    </p>
                </div>
            <?php endforeach; ?>
            
            <?php if (empty($recent_logs)): ?>
                <div style="text-align: center; padding: 2rem; color: var(--color-text-muted);">
                    Keine Aktivitäten vorhanden
                </div>
            <?php endif; ?>
        </div>
        
        <div class="mt-3">
            <a href="<?php echo ADMIN_PATH; ?>/logs" class="btn btn-secondary btn-sm">
                Alle Logs ansehen
            </a>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="card">
        <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">Schnellzugriff</h2>
        
        <div style="display: flex; flex-direction: column; gap: 0.75rem;">
            <a href="<?php echo ADMIN_PATH; ?>/links" class="btn btn-primary" style="justify-content: center;">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"/>
                </svg>
                Neuer Link
            </a>
            
            <a href="<?php echo ADMIN_PATH; ?>/links" class="btn btn-secondary" style="justify-content: center;">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"/>
                </svg>
                Links verwalten
            </a>
            
            <a href="<?php echo ADMIN_PATH; ?>/bans" class="btn btn-secondary" style="justify-content: center;">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/>
                </svg>
                Ban-Verwaltung
            </a>
            
            <a href="<?php echo ADMIN_PATH; ?>/messages" class="btn btn-secondary" style="justify-content: center;">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
                    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
                </svg>
                Nachrichten
            </a>
        </div>
        
        <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1px solid var(--color-border);">
            <h3 style="font-size: 1rem; margin-bottom: 1rem; color: var(--color-text-primary);">System-Info</h3>
            <div style="display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.875rem;">
                <div class="flex justify-between">
                    <span class="text-muted">PHP Version:</span>
                    <span style="color: var(--color-text-primary);"><?php echo phpversion(); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-muted">Server:</span>
                    <span style="color: var(--color-text-primary);"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-muted">Letzte Aktivität:</span>
                    <span style="color: var(--color-text-primary);">
                        <?php echo !empty($recent_logs) ? date('H:i', strtotime($recent_logs[0]['timestamp'])) : '-'; ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require BASE_PATH . '/admin/includes/footer.php'; ?>
