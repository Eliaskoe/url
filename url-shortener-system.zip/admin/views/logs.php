<?php
$page_title = 'System Logs';
require BASE_PATH . '/admin/includes/header.php';

$db = new Database();
$logs = array_reverse($db->getAllLogs());

// Filter
$filter_type = $_GET['type'] ?? 'all';
if ($filter_type !== 'all') {
    $logs = array_filter($logs, fn($log) => $log['type'] === $filter_type);
}
?>

<div class="card mb-4">
    <div class="flex justify-between items-center">
        <h2 style="margin: 0; font-size: 1.25rem; color: var(--color-blue-pastel);">Filter</h2>
        <div class="flex gap-2">
            <a href="?type=all" class="badge <?php echo $filter_type === 'all' ? 'badge-blue' : 'badge-secondary'; ?>">
                Alle
            </a>
            <a href="?type=visit" class="badge <?php echo $filter_type === 'visit' ? 'badge-success' : 'badge-secondary'; ?>">
                Visits
            </a>
            <a href="?type=admin" class="badge <?php echo $filter_type === 'admin' ? 'badge-blue' : 'badge-secondary'; ?>">
                Admin
            </a>
            <a href="?type=security" class="badge <?php echo $filter_type === 'security' ? 'badge-danger' : 'badge-secondary'; ?>">
                Security
            </a>
            <a href="?type=message" class="badge <?php echo $filter_type === 'message' ? 'badge-warning' : 'badge-secondary'; ?>">
                Messages
            </a>
        </div>
    </div>
</div>

<div class="card">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">
        System Logs (<?php echo count($logs); ?>)
    </h2>
    
    <?php if (empty($logs)): ?>
        <div style="text-align: center; padding: 3rem; color: var(--color-text-muted);">
            <p>Keine Logs vorhanden</p>
        </div>
    <?php else: ?>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
            <?php foreach ($logs as $log): ?>
                <div style="padding: 1.25rem; background: var(--color-bg-tertiary); border-radius: 8px; border-left: 4px solid <?php
                    echo $log['type'] === 'security' ? 'var(--color-danger)' : 
                         ($log['type'] === 'admin' ? 'var(--color-blue-medium)' : 
                          ($log['type'] === 'visit' ? 'var(--color-success)' : 'var(--color-warning)'));
                ?>;">
                    <div class="flex justify-between items-center mb-2">
                        <span class="badge <?php
                            echo $log['type'] === 'security' ? 'badge-danger' : 
                                 ($log['type'] === 'admin' ? 'badge-blue' : 
                                  ($log['type'] === 'visit' ? 'badge-success' : 'badge-warning'));
                        ?>"><?php echo strtoupper($log['type']); ?></span>
                        <span class="text-muted" style="font-size: 0.875rem;">
                            <?php echo date('d.m.Y H:i:s', strtotime($log['timestamp'])); ?>
                        </span>
                    </div>
                    
                    <p style="color: var(--color-text-primary); margin-bottom: 1rem;">
                        <?php echo htmlspecialchars($log['message']); ?>
                    </p>
                    
                    <?php if (!empty($log['data'])): ?>
                        <details style="background: var(--color-bg-secondary); border-radius: 6px; padding: 0.75rem;">
                            <summary style="cursor: pointer; color: var(--color-blue-light); font-size: 0.875rem; font-weight: 500;">
                                Zusätzliche Daten anzeigen
                            </summary>
                            <pre style="margin-top: 0.75rem; padding: 0.75rem; background: var(--color-bg-primary); border-radius: 6px; overflow-x: auto; font-size: 0.75rem; color: var(--color-text-secondary);"><?php echo htmlspecialchars(json_encode($log['data'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
                        </details>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php require BASE_PATH . '/admin/includes/footer.php'; ?>
