<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zugang gesperrt - URL Shortener</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="public-container">
        <div class="public-card">
            <svg class="public-icon danger" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/>
            </svg>
            
            <h1>Zugang gesperrt</h1>
            <p class="text-muted mt-2">Ihre IP-Adresse wurde blockiert</p>
            
            <div class="alert alert-error mt-4">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                <span>Ihr Zugang wurde aus Sicherheitsgründen eingeschränkt.</span>
            </div>
            
            <p class="mt-4 text-secondary text-small">
                Wenn Sie glauben, dass dies ein Fehler ist, können Sie einen Entbannungsantrag stellen.
            </p>
            
            <a href="/unban-request" class="btn btn-primary mt-4">
                Entbannung beantragen
            </a>
        </div>
    </div>
</body>
</html>
