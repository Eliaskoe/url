<?php
/**
 * Admin Panel - Router
 */

session_start();
require_once BASE_PATH . '/includes/config.php';
require_once BASE_PATH . '/includes/functions.php';
require_once BASE_PATH . '/includes/security.php';
require_once BASE_PATH . '/includes/auth.php';
require_once BASE_PATH . '/includes/storage.php';

$auth = new Auth();
$storage = new Storage();
$security = new Security();

// Admin-Pfad ermitteln
$adminPath = trim(str_replace(['cadmin', 'admin'], '', $path), '/');
$adminPath = empty($adminPath) ? 'dashboard' : $adminPath;

// Login-Seite
if ($adminPath === 'login') {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            setFlash('error', 'Ungültige Anfrage');
        } else {
            $result = $auth->login($username, $password);
            if ($result['success']) {
                redirect(ADMIN_PATH);
            } else {
                setFlash('error', $result['error']);
            }
        }
    }
    include BASE_PATH . '/admin/views/login.php';
    exit;
}

// Logout
if ($adminPath === 'logout') {
    $auth->logout();
    redirect(ADMIN_PATH . '/login');
}

// Ab hier Login erforderlich
$auth->requireLogin();
$currentUser = $auth->getCurrentUser();

// Admin-Routing
switch ($adminPath) {
    case 'dashboard':
        $stats = $storage->getStats();
        $recentLogs = $storage->getSecurityLogs(10);
        $recentVisitors = $storage->getVisitorLogs(10);
        include BASE_PATH . '/admin/views/dashboard.php';
        break;
    
    case 'links':
        $auth->requirePermission('view_links');
        $links = $storage->getLinks();
        
        // Link erstellen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $auth->requirePermission('manage_links');
            
            if ($_POST['action'] === 'create') {
                if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
                    setFlash('error', 'Ungültige Anfrage');
                } else {
                    $targetUrl = $_POST['target_url'] ?? '';
                    if (!isValidUrl($targetUrl)) {
                        setFlash('error', 'Ungültige URL');
                    } else {
                        $link = $storage->createLink([
                            'target_url' => $targetUrl,
                            'slug' => !empty($_POST['slug']) ? sanitize($_POST['slug']) : null,
                            'title' => sanitize($_POST['title'] ?? ''),
                            'warning_page' => isset($_POST['warning_page']),
                            'expires_at' => !empty($_POST['expires_at']) ? $_POST['expires_at'] : null,
                            'created_by' => $_SESSION['user_id']
                        ]);
                        setFlash('success', 'Link erstellt: ' . BASE_URL . '/' . $link['slug']);
                    }
                }
                redirect(ADMIN_PATH . '/links');
            }
            
            if ($_POST['action'] === 'update') {
                $linkId = $_POST['link_id'] ?? '';
                $storage->updateLink($linkId, [
                    'target_url' => $_POST['target_url'],
                    'title' => sanitize($_POST['title'] ?? ''),
                    'status' => $_POST['status'] ?? 'active',
                    'warning_page' => isset($_POST['warning_page']),
                    'expires_at' => !empty($_POST['expires_at']) ? $_POST['expires_at'] : null
                ]);
                setFlash('success', 'Link aktualisiert');
                redirect(ADMIN_PATH . '/links');
            }
            
            if ($_POST['action'] === 'delete') {
                $linkId = $_POST['link_id'] ?? '';
                $storage->deleteLink($linkId);
                setFlash('success', 'Link gelöscht');
                redirect(ADMIN_PATH . '/links');
            }
        }
        
        $links = $storage->getLinks();
        include BASE_PATH . '/admin/views/links.php';
        break;
    
    case 'users':
        $auth->requirePermission('manage_users');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
                setFlash('error', 'Ungültige Anfrage');
            } else {
                if ($_POST['action'] === 'create') {
                    $username = sanitize($_POST['username'] ?? '');
                    $password = $_POST['password'] ?? '';
                    
                    if (empty($username) || empty($password)) {
                        setFlash('error', 'Benutzername und Passwort erforderlich');
                    } elseif ($storage->getUserByUsername($username)) {
                        setFlash('error', 'Benutzername existiert bereits');
                    } else {
                        $permissions = $_POST['permissions'] ?? [];
                        $storage->createUser([
                            'username' => $username,
                            'password' => $password,
                            'role' => $_POST['role'] ?? 'user',
                            'permissions' => $permissions
                        ]);
                        setFlash('success', 'Benutzer erstellt');
                    }
                }
                
                if ($_POST['action'] === 'update') {
                    $userId = $_POST['user_id'] ?? '';
                    $updateData = [
                        'role' => $_POST['role'] ?? 'user',
                        'permissions' => $_POST['permissions'] ?? [],
                        'active' => isset($_POST['active'])
                    ];
                    if (!empty($_POST['password'])) {
                        $updateData['password'] = $_POST['password'];
                    }
                    $storage->updateUser($userId, $updateData);
                    setFlash('success', 'Benutzer aktualisiert');
                }
                
                if ($_POST['action'] === 'delete') {
                    $userId = $_POST['user_id'] ?? '';
                    if ($userId === $_SESSION['user_id']) {
                        setFlash('error', 'Eigenen Account nicht löschbar');
                    } else {
                        $storage->deleteUser($userId);
                        setFlash('success', 'Benutzer gelöscht');
                    }
                }
            }
            redirect(ADMIN_PATH . '/users');
        }
        
        $users = $storage->getUsers();
        include BASE_PATH . '/admin/views/users.php';
        break;
    
    case 'visitors':
        $auth->requirePermission('view_visitors');
        $visitors = $storage->getVisitorLogs(200);
        include BASE_PATH . '/admin/views/visitors.php';
        break;
    
    case 'security':
        $auth->requirePermission('view_security');
        $logs = $storage->getSecurityLogs(200);
        include BASE_PATH . '/admin/views/security.php';
        break;
    
    case 'bans':
        $auth->requirePermission('view_bans');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $auth->requirePermission('manage_bans');
            
            if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
                setFlash('error', 'Ungültige Anfrage');
            } else {
                if ($_POST['action'] === 'ban') {
                    $ip = sanitize($_POST['ip'] ?? '');
                    $reason = sanitize($_POST['reason'] ?? '');
                    $duration = !empty($_POST['duration']) ? intval($_POST['duration']) * 3600 : null;
                    
                    $storage->banIP($ip, $reason, $duration);
                    $security->logSecurityEvent('ip_banned', ['ip' => $ip, 'reason' => $reason, 'admin' => $_SESSION['username']]);
                    setFlash('success', 'IP gebannt: ' . $ip);
                }
                
                if ($_POST['action'] === 'unban') {
                    $ip = $_POST['ip'] ?? '';
                    $storage->unbanIP($ip);
                    $security->logSecurityEvent('ip_unbanned', ['ip' => $ip, 'admin' => $_SESSION['username']]);
                    setFlash('success', 'IP entbannt: ' . $ip);
                }
            }
            redirect(ADMIN_PATH . '/bans');
        }
        
        $bans = $storage->getBans();
        include BASE_PATH . '/admin/views/bans.php';
        break;
    
    case 'unban-requests':
        $auth->requirePermission('manage_unban_requests');
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
                setFlash('error', 'Ungültige Anfrage');
            } else {
                $requestId = $_POST['request_id'] ?? '';
                
                if ($_POST['action'] === 'approve') {
                    $requests = $storage->getUnbanRequests();
                    foreach ($requests as $req) {
                        if ($req['id'] === $requestId) {
                            $storage->unbanIP($req['ip']);
                            break;
                        }
                    }
                    $storage->updateUnbanRequest($requestId, [
                        'status' => 'approved',
                        'admin_response' => sanitize($_POST['response'] ?? 'Genehmigt')
                    ]);
                    setFlash('success', 'Antrag genehmigt');
                }
                
                if ($_POST['action'] === 'reject') {
                    $storage->updateUnbanRequest($requestId, [
                        'status' => 'rejected',
                        'admin_response' => sanitize($_POST['response'] ?? 'Abgelehnt')
                    ]);
                    setFlash('success', 'Antrag abgelehnt');
                }
                
                if ($_POST['action'] === 'respond') {
                    $storage->updateUnbanRequest($requestId, [
                        'admin_response' => sanitize($_POST['response'] ?? '')
                    ]);
                    setFlash('success', 'Antwort gespeichert');
                }
            }
            redirect(ADMIN_PATH . '/unban-requests');
        }
        
        $requests = $storage->getUnbanRequests();
        include BASE_PATH . '/admin/views/unban_requests.php';
        break;
    
    default:
        redirect(ADMIN_PATH);
}
