<?php
$redirect_url = $_SESSION['redirect_to'] ?? '/';
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warnung - EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card card-elevated" style="max-width: 600px; margin: 5rem auto;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="width: 80px; height: 80px; margin: 0 auto 1rem; background: rgba(245, 158, 11, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 40px; height: 40px; fill: var(--color-warning);" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                    </svg>
                </div>
                <h1 style="color: var(--color-warning); margin-bottom: 0.5rem;">Warnung</h1>
                <p class="text-muted">Sie werden zu einer externen Website weitergeleitet</p>
            </div>
            
            <div class="card" style="background: var(--color-bg-tertiary); margin-bottom: 2rem;">
                <p style="font-size: 0.875rem; color: var(--color-text-secondary); margin-bottom: 0.5rem;">Ziel-URL:</p>
                <p style="color: var(--color-blue-light); word-break: break-all; font-family: monospace; font-size: 0.875rem;">
                    <?php echo htmlspecialchars($redirect_url); ?>
                </p>
            </div>
            
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); border-radius: 8px; padding: 1rem; margin-bottom: 2rem;">
                <p style="font-size: 0.875rem; color: var(--color-text-secondary); line-height: 1.6;">
                    <strong style="color: var(--color-danger);">Vorsicht:</strong> Prüfen Sie die URL sorgfältig, bevor Sie fortfahren. 
                    Verlassen Sie diese Seite nicht, wenn Ihnen die URL verdächtig vorkommt.
                </p>
            </div>
            
            <div class="flex gap-2">
                <a href="/" class="btn btn-secondary" style="flex: 1; justify-content: center;">
                    Abbrechen
                </a>
                <a href="<?php echo htmlspecialchars($redirect_url); ?>" class="btn btn-primary" style="flex: 1; justify-content: center;">
                    Fortfahren
                </a>
            </div>
        </div>
    </div>
</body>
</html>
