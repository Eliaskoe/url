<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Admin'; ?> - EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
    <link rel="stylesheet" href="/assets/admin.css">
</head>
<body>
    <div class="admin-layout">
        <!-- Sidebar Navigation -->
        <aside class="admin-sidebar">
            <div class="admin-logo">
                <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--color-blue-dark), var(--color-blue-medium)); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 24px; height: 24px; fill: white;" viewBox="0 0 20 20">
                        <path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5.002 5.002 0 0010 2z"/>
                    </svg>
                </div>
                <div>
                    <div style="font-weight: 700; color: var(--color-text-primary);">EDK Admin</div>
                    <div style="font-size: 0.75rem; color: var(--color-text-muted);">URL Management</div>
                </div>
            </div>
            
            <nav class="admin-nav">
                <a href="<?php echo ADMIN_PATH; ?>" class="admin-nav-item <?php echo ($admin_path === '' || $admin_path === 'dashboard') ? 'active' : ''; ?>">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zM3 10a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H4a1 1 0 01-1-1v-6zM14 9a1 1 0 00-1 1v6a1 1 0 001 1h2a1 1 0 001-1v-6a1 1 0 00-1-1h-2z"/>
                    </svg>
                    Dashboard
                </a>
                
                <a href="<?php echo ADMIN_PATH; ?>/links" class="admin-nav-item <?php echo $admin_path === 'links' ? 'active' : ''; ?>">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clip-rule="evenodd"/>
                    </svg>
                    Links
                </a>
                
                <a href="<?php echo ADMIN_PATH; ?>/logs" class="admin-nav-item <?php echo $admin_path === 'logs' ? 'active' : ''; ?>">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"/>
                        <path fill-rule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z" clip-rule="evenodd"/>
                    </svg>
                    Logs
                </a>
                
                <a href="<?php echo ADMIN_PATH; ?>/bans" class="admin-nav-item <?php echo $admin_path === 'bans' ? 'active' : ''; ?>">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/>
                    </svg>
                    Bans
                </a>
                
                <a href="<?php echo ADMIN_PATH; ?>/messages" class="admin-nav-item <?php echo $admin_path === 'messages' ? 'active' : ''; ?>">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
                        <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
                    </svg>
                    Nachrichten
                    <?php
                    $db = new Database();
                    $messages = $db->getAllMessages();
                    $pending_count = count(array_filter($messages, fn($m) => $m['status'] === 'pending'));
                    if ($pending_count > 0):
                    ?>
                        <span class="badge badge-danger" style="margin-left: auto;"><?php echo $pending_count; ?></span>
                    <?php endif; ?>
                </a>
            </nav>
            
            <div class="admin-sidebar-footer">
                <a href="<?php echo ADMIN_PATH; ?>/logout" class="admin-nav-item" style="color: var(--color-danger);">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clip-rule="evenodd"/>
                    </svg>
                    Abmelden
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="admin-main">
            <div class="admin-header">
                <h1><?php echo $page_title ?? 'Admin'; ?></h1>
                <div class="flex items-center gap-2">
                    <span class="text-muted" style="font-size: 0.875rem;">
                        <?php echo date('d.m.Y H:i'); ?>
                    </span>
                </div>
            </div>
            
            <div class="admin-content">
