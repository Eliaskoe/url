<?php
/**
 * Logger Klasse
 * Umfangreiches Logging für Admin-Panel
 */
class Logger {
    private $db;
    
    public function __construct() {
        $this->db = new Database();
    }
    
    public function logVisit($slug, $visitor_data) {
        // Visit im Link-Counter erhöhen
        $link = $this->db->getLinkBySlug($slug);
        if ($link) {
            $this->db->updateLink($slug, [
                'clicks' => ($link['clicks'] ?? 0) + 1
            ]);
        }
        
        // Detailliertes Visit-Log
        $this->db->addLog('visit', "Visit to /{$slug}", [
            'slug' => $slug,
            'visitor' => $visitor_data
        ]);
    }
}
