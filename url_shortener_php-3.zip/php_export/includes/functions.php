<?php
/**
 * Hilfsfunktionen
 */

/**
 * Zufälligen Slug generieren
 */
function generateSlug($length = SLUG_LENGTH) {
    $chars = SLUG_CHARS;
    $slug = '';
    for ($i = 0; $i < $length; $i++) {
        $slug .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $slug;
}

/**
 * Sicheres Passwort-Hash
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID);
}

/**
 * Passwort verifizieren
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * UUID generieren
 */
function generateUUID() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        random_int(0, 0xffff), random_int(0, 0xffff),
        random_int(0, 0xffff),
        random_int(0, 0x0fff) | 0x4000,
        random_int(0, 0x3fff) | 0x8000,
        random_int(0, 0xffff), random_int(0, 0xffff), random_int(0, 0xffff)
    );
}

/**
 * JSON Response senden
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

/**
 * Input sanitizen
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * URL validieren
 */
function isValidUrl($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Zeitstempel formatieren
 */
function formatDateTime($timestamp) {
    return date('d.m.Y H:i:s', strtotime($timestamp));
}

/**
 * Relativer Zeitstempel
 */
function timeAgo($datetime) {
    $now = new DateTime();
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    
    if ($diff->y > 0) return 'vor ' . $diff->y . ' Jahr(en)';
    if ($diff->m > 0) return 'vor ' . $diff->m . ' Monat(en)';
    if ($diff->d > 0) return 'vor ' . $diff->d . ' Tag(en)';
    if ($diff->h > 0) return 'vor ' . $diff->h . ' Stunde(n)';
    if ($diff->i > 0) return 'vor ' . $diff->i . ' Minute(n)';
    return 'gerade eben';
}

/**
 * CSRF Token generieren
 */
function generateCSRFToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token validieren
 */
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Flash-Nachricht setzen
 */
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

/**
 * Flash-Nachricht abrufen und löschen
 */
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Redirect
 */
function redirect($url) {
    header('Location: ' . $url);
    exit;
}
