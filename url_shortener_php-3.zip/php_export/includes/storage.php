<?php
/**
 * Storage-Klasse
 * Lokale JSON-Datei Speicherung
 */

class Storage {
    private $dataPath;
    
    public function __construct() {
        $this->dataPath = DATA_PATH;
        $this->ensureDataFiles();
    }
    
    /**
     * Daten-Dateien initialisieren
     */
    private function ensureDataFiles() {
        $files = [
            'users.json' => [],
            'links.json' => [],
            'visitors.json' => [],
            'security_logs.json' => [],
            'clicks.json' => [],
            'bans.json' => [],
            'unban_requests.json' => [],
            'settings.json' => ['site_name' => 'URL Shortener', 'domain' => 'url.edk.codes']
        ];
        
        foreach ($files as $file => $default) {
            $path = $this->dataPath . '/' . $file;
            if (!file_exists($path)) {
                $this->writeJson($path, $default);
            }
        }
    }
    
    /**
     * JSON lesen
     */
    private function readJson($file) {
        $path = $this->dataPath . '/' . $file;
        if (!file_exists($path)) {
            return [];
        }
        $content = file_get_contents($path);
        return json_decode($content, true) ?: [];
    }
    
    /**
     * JSON schreiben
     */
    private function writeJson($path, $data) {
        if (strpos($path, '/') === false) {
            $path = $this->dataPath . '/' . $path;
        }
        $dir = dirname($path);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    }
    
    // ==================== USERS ====================
    
    /**
     * Benutzer abrufen
     */
    public function getUsers() {
        return $this->readJson('users.json');
    }
    
    /**
     * Benutzer nach Username
     */
    public function getUserByUsername($username) {
        $users = $this->getUsers();
        foreach ($users as $user) {
            if ($user['username'] === $username) {
                return $user;
            }
        }
        return null;
    }
    
    /**
     * Benutzer nach ID
     */
    public function getUserById($id) {
        $users = $this->getUsers();
        foreach ($users as $user) {
            if ($user['id'] === $id) {
                return $user;
            }
        }
        return null;
    }
    
    /**
     * Benutzer erstellen
     */
    public function createUser($data) {
        $users = $this->getUsers();
        $user = [
            'id' => generateUUID(),
            'username' => $data['username'],
            'password' => hashPassword($data['password']),
            'role' => $data['role'] ?? 'user',
            'permissions' => $data['permissions'] ?? [],
            'created_at' => date('Y-m-d H:i:s'),
            'last_login' => null,
            'active' => true
        ];
        $users[] = $user;
        $this->writeJson('users.json', $users);
        return $user;
    }
    
    /**
     * Benutzer aktualisieren
     */
    public function updateUser($id, $data) {
        $users = $this->getUsers();
        foreach ($users as &$user) {
            if ($user['id'] === $id) {
                foreach ($data as $key => $value) {
                    if ($key === 'password' && !empty($value)) {
                        $user['password'] = hashPassword($value);
                    } else {
                        $user[$key] = $value;
                    }
                }
                $user['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        $this->writeJson('users.json', $users);
    }
    
    /**
     * Benutzer löschen
     */
    public function deleteUser($id) {
        $users = $this->getUsers();
        $users = array_filter($users, fn($u) => $u['id'] !== $id);
        $this->writeJson('users.json', array_values($users));
    }
    
    // ==================== LINKS ====================
    
    /**
     * Alle Links abrufen
     */
    public function getLinks() {
        return $this->readJson('links.json');
    }
    
    /**
     * Link nach Slug
     */
    public function getLinkBySlug($slug) {
        $links = $this->getLinks();
        foreach ($links as $link) {
            if ($link['slug'] === $slug) {
                return $link;
            }
        }
        return null;
    }
    
    /**
     * Link nach ID
     */
    public function getLinkById($id) {
        $links = $this->getLinks();
        foreach ($links as $link) {
            if ($link['id'] === $id) {
                return $link;
            }
        }
        return null;
    }
    
    /**
     * Link erstellen
     */
    public function createLink($data) {
        $links = $this->getLinks();
        
        // Slug generieren wenn nicht angegeben
        $slug = $data['slug'] ?? generateSlug();
        while ($this->getLinkBySlug($slug)) {
            $slug = generateSlug();
        }
        
        $link = [
            'id' => generateUUID(),
            'slug' => $slug,
            'target_url' => $data['target_url'],
            'title' => $data['title'] ?? '',
            'status' => $data['status'] ?? 'active',
            'warning_page' => $data['warning_page'] ?? false,
            'expires_at' => $data['expires_at'] ?? null,
            'clicks' => 0,
            'created_by' => $data['created_by'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        $links[] = $link;
        $this->writeJson('links.json', $links);
        return $link;
    }
    
    /**
     * Link aktualisieren
     */
    public function updateLink($id, $data) {
        $links = $this->getLinks();
        foreach ($links as &$link) {
            if ($link['id'] === $id) {
                foreach ($data as $key => $value) {
                    $link[$key] = $value;
                }
                $link['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        $this->writeJson('links.json', $links);
    }
    
    /**
     * Link löschen
     */
    public function deleteLink($id) {
        $links = $this->getLinks();
        $links = array_filter($links, fn($l) => $l['id'] !== $id);
        $this->writeJson('links.json', array_values($links));
    }
    
    /**
     * Klick loggen
     */
    public function logClick($linkId, $ip, $userAgent, $referer) {
        // Link-Klicks erhöhen
        $links = $this->getLinks();
        foreach ($links as &$link) {
            if ($link['id'] === $linkId) {
                $link['clicks'] = ($link['clicks'] ?? 0) + 1;
                break;
            }
        }
        $this->writeJson('links.json', $links);
        
        // Klick-Details speichern
        $clicks = $this->readJson('clicks.json');
        $clicks[] = [
            'id' => generateUUID(),
            'link_id' => $linkId,
            'ip' => $ip,
            'user_agent' => $userAgent,
            'referer' => $referer,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Max 10000 Klicks behalten
        if (count($clicks) > 10000) {
            $clicks = array_slice($clicks, -10000);
        }
        
        $this->writeJson('clicks.json', $clicks);
    }
    
    // ==================== VISITORS ====================
    
    /**
     * Besucher-Log speichern
     */
    public function saveVisitorLog($data) {
        $visitors = $this->readJson('visitors.json');
        $visitors[] = $data;
        
        // Max 5000 Einträge
        if (count($visitors) > 5000) {
            $visitors = array_slice($visitors, -5000);
        }
        
        $this->writeJson('visitors.json', $visitors);
    }
    
    /**
     * Besucher-Logs abrufen
     */
    public function getVisitorLogs($limit = 100, $offset = 0) {
        $visitors = $this->readJson('visitors.json');
        $visitors = array_reverse($visitors);
        return array_slice($visitors, $offset, $limit);
    }
    
    /**
     * Besucher nach IP
     */
    public function getVisitorsByIP($ip) {
        $visitors = $this->readJson('visitors.json');
        return array_filter($visitors, fn($v) => $v['ip'] === $ip);
    }
    
    // ==================== SECURITY LOGS ====================
    
    /**
     * Security-Log speichern
     */
    public function saveSecurityLog($data) {
        $logs = $this->readJson('security_logs.json');
        $logs[] = $data;
        
        // Max 2000 Einträge
        if (count($logs) > 2000) {
            $logs = array_slice($logs, -2000);
        }
        
        $this->writeJson('security_logs.json', $logs);
    }
    
    /**
     * Security-Logs abrufen
     */
    public function getSecurityLogs($limit = 100, $offset = 0) {
        $logs = $this->readJson('security_logs.json');
        $logs = array_reverse($logs);
        return array_slice($logs, $offset, $limit);
    }
    
    // ==================== BANS ====================
    
    /**
     * IP bannen
     */
    public function banIP($ip, $reason = '', $duration = null) {
        $bans = $this->readJson('bans.json');
        
        // Existierenden Ban aktualisieren oder neuen erstellen
        $found = false;
        foreach ($bans as &$ban) {
            if ($ban['ip'] === $ip) {
                $ban['reason'] = $reason;
                $ban['banned_at'] = date('Y-m-d H:i:s');
                $ban['expires_at'] = $duration ? date('Y-m-d H:i:s', time() + $duration) : null;
                $ban['active'] = true;
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            $bans[] = [
                'id' => generateUUID(),
                'ip' => $ip,
                'reason' => $reason,
                'banned_at' => date('Y-m-d H:i:s'),
                'expires_at' => $duration ? date('Y-m-d H:i:s', time() + $duration) : null,
                'active' => true
            ];
        }
        
        $this->writeJson('bans.json', $bans);
    }
    
    /**
     * IP entbannen
     */
    public function unbanIP($ip) {
        $bans = $this->readJson('bans.json');
        foreach ($bans as &$ban) {
            if ($ban['ip'] === $ip) {
                $ban['active'] = false;
                $ban['unbanned_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        $this->writeJson('bans.json', $bans);
    }
    
    /**
     * IP-Ban prüfen
     */
    public function isIPBanned($ip) {
        $bans = $this->readJson('bans.json');
        foreach ($bans as $ban) {
            if ($ban['ip'] === $ip && $ban['active']) {
                // Timeout prüfen
                if (!empty($ban['expires_at']) && strtotime($ban['expires_at']) < time()) {
                    $this->unbanIP($ip);
                    return false;
                }
                return true;
            }
        }
        return false;
    }
    
    /**
     * Alle Bans abrufen
     */
    public function getBans() {
        return $this->readJson('bans.json');
    }
    
    // ==================== UNBAN REQUESTS ====================
    
    /**
     * Entbann-Antrag erstellen
     */
    public function createUnbanRequest($data) {
        $requests = $this->readJson('unban_requests.json');
        $request = [
            'id' => generateUUID(),
            'ip' => $data['ip'],
            'email' => $data['email'] ?? '',
            'message' => $data['message'],
            'status' => 'pending',
            'admin_response' => null,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $requests[] = $request;
        $this->writeJson('unban_requests.json', $requests);
        return $request;
    }
    
    /**
     * Entbann-Anträge abrufen
     */
    public function getUnbanRequests() {
        return array_reverse($this->readJson('unban_requests.json'));
    }
    
    /**
     * Entbann-Antrag aktualisieren
     */
    public function updateUnbanRequest($id, $data) {
        $requests = $this->readJson('unban_requests.json');
        foreach ($requests as &$request) {
            if ($request['id'] === $id) {
                foreach ($data as $key => $value) {
                    $request[$key] = $value;
                }
                $request['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        $this->writeJson('unban_requests.json', $requests);
    }
    
    // ==================== STATS ====================
    
    /**
     * Dashboard-Statistiken
     */
    public function getStats() {
        $links = $this->getLinks();
        $visitors = $this->readJson('visitors.json');
        $bans = $this->getBans();
        $securityLogs = $this->readJson('security_logs.json');
        
        $activeLinks = count(array_filter($links, fn($l) => $l['status'] === 'active'));
        $totalClicks = array_sum(array_column($links, 'clicks'));
        $activeBans = count(array_filter($bans, fn($b) => $b['active']));
        $criticalEvents = count(array_filter($securityLogs, fn($l) => $l['severity'] === 'critical'));
        
        // Heute
        $today = date('Y-m-d');
        $todayVisitors = count(array_filter($visitors, fn($v) => strpos($v['timestamp'], $today) === 0));
        
        return [
            'total_links' => count($links),
            'active_links' => $activeLinks,
            'total_clicks' => $totalClicks,
            'total_visitors' => count($visitors),
            'today_visitors' => $todayVisitors,
            'active_bans' => $activeBans,
            'critical_events' => $criticalEvents,
            'total_security_events' => count($securityLogs)
        ];
    }
}
