<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bans - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header flex justify-between items-center">
                <div>
                    <h1 class="page-title">IP-Bans verwalten</h1>
                    <p class="page-subtitle"><?= count(array_filter($bans, fn($b) => $b['active'])) ?> aktive Bans</p>
                </div>
                <?php if ($auth->hasPermission('manage_bans')): ?>
                <button class="btn btn-primary" onclick="openModal('banModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                    IP bannen
                </button>
                <?php endif; ?>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>IP-Adresse</th>
                            <th>Grund</th>
                            <th>Status</th>
                            <th>Gebannt am</th>
                            <th>Läuft ab</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($bans)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted" style="padding: 2rem;">Keine Bans vorhanden</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach (array_reverse($bans) as $ban): ?>
                            <tr>
                                <td>
                                    <span class="ip-display"><?= htmlspecialchars($ban['ip']) ?></span>
                                </td>
                                <td>
                                    <span class="text-small"><?= htmlspecialchars($ban['reason'] ?: '-') ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-<?= $ban['active'] ? 'danger' : 'success' ?>">
                                        <?= $ban['active'] ? 'Gebannt' : 'Entbannt' ?>
                                    </span>
                                </td>
                                <td class="text-small text-muted">
                                    <?= formatDateTime($ban['banned_at']) ?>
                                </td>
                                <td class="text-small">
                                    <?php if (!empty($ban['expires_at'])): ?>
                                        <?php if (strtotime($ban['expires_at']) < time()): ?>
                                            <span class="badge badge-success">Abgelaufen</span>
                                        <?php else: ?>
                                            <?= formatDateTime($ban['expires_at']) ?>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Permanent</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($ban['active'] && $auth->hasPermission('manage_bans')): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                        <input type="hidden" name="action" value="unban">
                                        <input type="hidden" name="ip" value="<?= htmlspecialchars($ban['ip']) ?>">
                                        <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('IP wirklich entbannen?');">
                                            Entbannen
                                        </button>
                                    </form>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <!-- Ban Modal -->
    <div class="modal-overlay" id="banModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">IP bannen</h3>
                <button class="modal-close" onclick="closeModal('banModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                <input type="hidden" name="action" value="ban">
                
                <div class="form-group">
                    <label class="form-label" for="ip">IP-Adresse *</label>
                    <input type="text" id="ip" name="ip" class="form-input" placeholder="192.168.1.1" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="reason">Grund</label>
                    <input type="text" id="reason" name="reason" class="form-input" placeholder="Optional">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="duration">Dauer (Stunden)</label>
                    <input type="number" id="duration" name="duration" class="form-input" placeholder="Leer = Permanent">
                    <small class="text-muted">Leer lassen für permanenten Ban</small>
                </div>
                
                <div class="flex gap-2 justify-between">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('banModal')">Abbrechen</button>
                    <button type="submit" class="btn btn-danger">IP bannen</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function openModal(id) {
            document.getElementById(id).classList.add('active');
        }
        
        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }
        
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
            }
        });
        
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
