# EDK URL Shortener

Professionelles PHP-basiertes URL-Shortener-System mit umfangreichem Admin-Panel.

## Installation

1. **Dateien hochladen**
   ```bash
   # Alle Dateien nach /var/www/edk/url.edk/ kopieren
   ```

2. **Berechtigungen setzen**
   ```bash
   sudo chown -R www-data:www-data /var/www/edk/url.edk
   sudo chmod -R 755 /var/www/edk/url.edk
   sudo chmod -R 775 /var/www/edk/url.edk/data
   ```

3. **Nginx konfigurieren**
   ```bash
   sudo cp .nginx-example.conf /etc/nginx/sites-available/url.edk.codes
   sudo ln -s /etc/nginx/sites-available/url.edk.codes /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl reload nginx
   ```

4. **Admin-Zugang einrichten**
   - Öffnen Sie `/cadmin` in Ihrem Browser
   - Standard-Passwort: `admin123` (BITTE ÄNDERN!)

## Features

- ✅ URL-Shortener mit Custom Slugs
- ✅ Admin-Panel unter `/cadmin`
- ✅ Cookie-basierte Security mit Manipulation-Detection
- ✅ IP-Tracking & Logging
- ✅ Ban-System (temporär & permanent)
- ✅ Entbann-Anfragen
- ✅ JSON-basierte Datenspeicherung
- ✅ Dark Mode Professional Design
- ✅ GeoIP-Tracking
- ✅ Vorschaltseiten

## Sicherheit

- Hash-basierte Cookies (HMAC SHA-256)
- Cookie-Manipulations-Erkennung
- Automatisches Bannen bei Manipulation
- IP-Logging
- Session-Security

## Struktur

```
/var/www/edk/url.edk/
├── index.php              # Front Controller
├── classes/
│   ├── Router.php         # URL Routing
│   ├── Database.php       # JSON Storage
│   ├── Security.php       # Security & Bans
│   └── Logger.php         # Logging System
├── admin/
│   └── controller.php     # Admin Panel
├── views/
│   ├── home.php          # Homepage
│   ├── 404.php           # Not Found
│   ├── unban.php         # Unban Request
│   └── warning.php       # Warning Page
├── assets/
│   └── style.css         # Dark Blue Theme
└── data/                 # JSON Files (auto-created)
    ├── links.json
    ├── logs.json
    ├── bans.json
    └── messages.json
```

## Nächste Schritte

Das System wird weiter entwickelt mit:
- Admin-Panel (Dashboard, Link-Verwaltung)
- Erweiterte Logging-Ansicht
- Statistiken & Analytics
- Message-System
