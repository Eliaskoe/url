<?php
/**
 * Authentifizierungs-Klasse
 */

class Auth {
    private $storage;
    private $security;
    
    public function __construct() {
        $this->storage = new Storage();
        $this->security = new Security();
    }
    
    /**
     * Login
     */
    public function login($username, $password) {
        $user = $this->storage->getUserByUsername($username);
        
        if (!$user) {
            $this->security->logSecurityEvent('login_failed', [
                'username' => $username,
                'reason' => 'user_not_found'
            ]);
            return ['success' => false, 'error' => 'Ungültige Anmeldedaten'];
        }
        
        if (!$user['active']) {
            $this->security->logSecurityEvent('login_failed', [
                'username' => $username,
                'reason' => 'user_inactive'
            ]);
            return ['success' => false, 'error' => 'Benutzer deaktiviert'];
        }
        
        if (!verifyPassword($password, $user['password'])) {
            $this->security->logSecurityEvent('login_failed', [
                'username' => $username,
                'reason' => 'wrong_password'
            ]);
            return ['success' => false, 'error' => 'Ungültige Anmeldedaten'];
        }
        
        // Login erfolgreich
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        $_SESSION['permissions'] = $user['permissions'];
        $_SESSION['login_time'] = time();
        
        // Session regenerieren
        session_regenerate_id(true);
        
        // Last Login aktualisieren
        $this->storage->updateUser($user['id'], ['last_login' => date('Y-m-d H:i:s')]);
        
        $this->security->logSecurityEvent('login_success', [
            'username' => $username,
            'user_id' => $user['id']
        ]);
        
        return ['success' => true, 'user' => $user];
    }
    
    /**
     * Logout
     */
    public function logout() {
        $_SESSION = [];
        
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }
        
        session_destroy();
    }
    
    /**
     * Eingeloggt prüfen
     */
    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
    }
    
    /**
     * Admin prüfen
     */
    public function isAdmin() {
        return $this->isLoggedIn() && $_SESSION['role'] === 'admin';
    }
    
    /**
     * Berechtigung prüfen
     */
    public function hasPermission($permission) {
        if ($this->isAdmin()) {
            return true; // Admin hat alle Rechte
        }
        
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        $permissions = $_SESSION['permissions'] ?? [];
        return in_array($permission, $permissions);
    }
    
    /**
     * Aktueller Benutzer
     */
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        return $this->storage->getUserById($_SESSION['user_id']);
    }
    
    /**
     * Login erforderlich
     */
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            redirect(ADMIN_PATH . '/login');
        }
    }
    
    /**
     * Admin erforderlich
     */
    public function requireAdmin() {
        $this->requireLogin();
        if (!$this->isAdmin()) {
            setFlash('error', 'Keine Berechtigung für diese Aktion');
            redirect(ADMIN_PATH);
        }
    }
    
    /**
     * Berechtigung erforderlich
     */
    public function requirePermission($permission) {
        $this->requireLogin();
        if (!$this->hasPermission($permission)) {
            setFlash('error', 'Keine Berechtigung: ' . $permission);
            redirect(ADMIN_PATH);
        }
    }
}

// Verfügbare Berechtigungen
define('PERMISSIONS', [
    'view_dashboard' => 'Dashboard anzeigen',
    'manage_links' => 'Links verwalten',
    'view_links' => 'Links anzeigen',
    'view_logs' => 'Logs anzeigen',
    'view_visitors' => 'Besucher anzeigen',
    'view_ips' => 'IP-Adressen anzeigen',
    'manage_bans' => 'Bans verwalten',
    'view_bans' => 'Bans anzeigen',
    'manage_users' => 'Benutzer verwalten',
    'view_security' => 'Sicherheitslogs anzeigen',
    'manage_unban_requests' => 'Entbann-Anträge verwalten',
    'view_settings' => 'Einstellungen anzeigen'
]);
