<?php
/**
 * Admin Controller
 * Verwaltet alle Admin-Panel Requests
 */

// Admin-spezifische Konstanten
define('ADMIN_PASSWORD_HASH', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'); // admin123
// WICHTIG: Passwort-Hash mit password_hash('ihr_passwort', PASSWORD_DEFAULT) generieren!

// Admin Session prüfen
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function requireAdminLogin() {
    if (!isAdminLoggedIn()) {
        header('Location: ' . ADMIN_PATH . '/login');
        exit;
    }
}

// Request URI parsen
$admin_path = str_replace(ADMIN_PATH, '', parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$admin_path = trim($admin_path, '/');

// Login-Handler
if ($admin_path === 'login') {
    if (isAdminLoggedIn()) {
        header('Location: ' . ADMIN_PATH);
        exit;
    }
    
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $password = $_POST['password'] ?? '';
        
        if (password_verify($password, ADMIN_PASSWORD_HASH)) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_login_time'] = time();
            
            $db = new Database();
            $db->addLog('admin', 'Admin logged in', ['ip' => $_SERVER['REMOTE_ADDR']]);
            
            header('Location: ' . ADMIN_PATH);
            exit;
        } else {
            $error = 'Falsches Passwort';
            $db = new Database();
            $db->addLog('security', 'Failed admin login attempt', ['ip' => $_SERVER['REMOTE_ADDR']]);
        }
    }
    
    require BASE_PATH . '/admin/views/login.php';
    exit;
}

// Logout-Handler
if ($admin_path === 'logout') {
    $db = new Database();
    $db->addLog('admin', 'Admin logged out', ['ip' => $_SERVER['REMOTE_ADDR']]);
    
    session_destroy();
    header('Location: ' . ADMIN_PATH . '/login');
    exit;
}

// Ab hier Login erforderlich
requireAdminLogin();

// Admin-Routes
switch ($admin_path) {
    case '':
    case 'dashboard':
        require BASE_PATH . '/admin/views/dashboard.php';
        break;
        
    case 'links':
        require BASE_PATH . '/admin/views/links.php';
        break;
        
    case 'logs':
        require BASE_PATH . '/admin/views/logs.php';
        break;
        
    case 'bans':
        require BASE_PATH . '/admin/views/bans.php';
        break;
        
    case 'messages':
        require BASE_PATH . '/admin/views/messages.php';
        break;
        
    case 'api':
        require BASE_PATH . '/admin/api.php';
        break;
        
    default:
        http_response_code(404);
        echo 'Admin page not found';
        break;
}
