# URL Shortener System

## Domain
- **Hauptdomain:** url.edk.codes
- **Admin-Panel:** url.edk.codes/cadmin

## Installation

### 1. Dateien kopieren
```bash
# Alle Dateien nach /var/www/edk/url.edk/ kopieren
cp -r * /var/www/edk/url.edk/
```

### 2. Setup ausführen
```bash
cd /var/www/edk/url.edk/
chmod +x autorun.sh
./autorun.sh
```

### 3. Nginx konfigurieren
```bash
# Konfiguration kopieren
cp nginx.conf.example /etc/nginx/sites-available/url.edk.codes

# Aktivieren
ln -s /etc/nginx/sites-available/url.edk.codes /etc/nginx/sites-enabled/

# Testen & Neustarten
nginx -t
systemctl restart nginx
```

## Admin-Zugangsdaten
- **Benutzername:** Elias061010
- **Passwort:** Elias061010

⚠️ **Passwort nach erstem Login ändern!**

## Struktur

```
/var/www/edk/url.edk/
├── index.php              # Front Controller
├── autorun.sh             # Setup-Script
├── setup.php              # Admin-Erstellung
├── nginx.conf.example     # Nginx-Konfiguration
├── admin/                 # Admin-Panel
│   ├── index.php
│   └── views/
│       ├── login.php
│       ├── dashboard.php
│       ├── links.php
│       ├── users.php
│       ├── visitors.php
│       ├── security.php
│       ├── bans.php
│       ├── unban_requests.php
│       └── partials/
│           └── sidebar.php
├── includes/              # PHP-Klassen
│   ├── config.php
│   ├── functions.php
│   ├── security.php
│   ├── auth.php
│   ├── storage.php
│   └── api.php
├── templates/             # Öffentliche Seiten
│   ├── home.php
│   ├── banned.php
│   ├── unban_request.php
│   ├── 404.php
│   ├── link_inactive.php
│   ├── link_expired.php
│   └── warning_page.php
├── assets/
│   └── css/
│       └── style.css
└── data/                  # JSON-Daten (777)
    ├── users.json
    ├── links.json
    ├── visitors.json
    ├── security_logs.json
    ├── clicks.json
    ├── bans.json
    ├── unban_requests.json
    └── settings.json
```

## Features

### Links
- Kurzlinks erstellen (automatisch oder custom)
- Ziel-URL ändern
- Ablaufzeit setzen
- Vorschaltseite aktivieren
- Status: aktiv/inaktiv/gesperrt

### Benutzer-Verwaltung
- Admin kann Benutzer erstellen
- Individuelle Berechtigungen:
  - `view_dashboard` - Dashboard anzeigen
  - `manage_links` - Links verwalten
  - `view_links` - Links anzeigen
  - `view_logs` - Logs anzeigen
  - `view_visitors` - Besucher anzeigen
  - `view_ips` - IP-Adressen anzeigen
  - `manage_bans` - Bans verwalten
  - `view_bans` - Bans anzeigen
  - `manage_users` - Benutzer verwalten
  - `view_security` - Sicherheitslogs anzeigen
  - `manage_unban_requests` - Entbann-Anträge verwalten

### Sicherheit
- Cookie-Manipulationserkennung
- Automatisches IP-Banning bei Manipulation
- Session-Schutz
- CSRF-Token
- XSS-Schutz

### Logging
- Besucher-Logging (IP, User-Agent, Referer, etc.)
- Security-Event-Logging
- Klick-Statistiken

### Ban-System
- IP bannen (permanent oder temporär)
- Entbann-Anträge
- Admin-Benachrichtigung
