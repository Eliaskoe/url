<?php
/**
 * Konfiguration
 */

// Basis-URL
define('BASE_URL', 'https://url.edk.codes');

// Admin-Pfad
define('ADMIN_PATH', '/cadmin');

// Session-Einstellungen
define('SESSION_LIFETIME', 86400); // 24 Stunden
define('SESSION_NAME', 'url_session');

// Cookie-Sicherheit
define('COOKIE_SECRET', 'CHANGE_THIS_TO_RANDOM_STRING_' . md5(__FILE__));
define('COOKIE_LIFETIME', 2592000); // 30 Tage

// Slug-Einstellungen
define('SLUG_LENGTH', 6);
define('SLUG_CHARS', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');

// Sicherheit
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 Minuten
define('BAN_COOKIE_NAME', 'url_ban_check');

// Logging
define('LOG_VISITORS', true);
define('LOG_SECURITY_EVENTS', true);

// Zeitzone
date_default_timezone_set('Europe/Berlin');
