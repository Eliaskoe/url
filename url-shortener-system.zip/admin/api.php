<?php
/**
 * Admin API Endpoints
 * Für AJAX-Requests
 */

header('Content-Type: application/json');

$db = new Database();
$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {
    case 'stats':
        $links = $db->getAllLinks();
        $logs = $db->getAllLogs();
        $bans = $db->getAllBans();
        
        echo json_encode([
            'success' => true,
            'data' => [
                'total_links' => count($links),
                'active_links' => count(array_filter($links, fn($l) => $l['status'] === 'active')),
                'total_clicks' => array_sum(array_column($links, 'clicks')),
                'total_bans' => count($bans),
                'recent_logs_count' => count($logs)
            ]
        ]);
        break;
        
    case 'check_slug':
        $slug = $_GET['slug'] ?? '';
        $exists = $db->getLinkBySlug($slug) !== null;
        
        echo json_encode([
            'success' => true,
            'exists' => $exists
        ]);
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'error' => 'Invalid action'
        ]);
        break;
}
