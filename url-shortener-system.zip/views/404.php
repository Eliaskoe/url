<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link nicht gefunden - EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card card-elevated text-center" style="max-width: 500px; margin: 5rem auto;">
            <div style="font-size: 4rem; margin-bottom: 1rem;">🔍</div>
            <h1 style="color: var(--color-blue-pastel); margin-bottom: 1rem;">Link nicht gefunden</h1>
            <p class="text-muted">Der angeforderte Kurzlink existiert nicht.</p>
            <a href="/" class="btn btn-primary mt-3">Zurück zur Startseite</a>
        </div>
    </div>
</body>
</html>
