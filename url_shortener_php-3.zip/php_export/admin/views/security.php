<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Logs - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Security Logs</h1>
                <p class="page-subtitle">Sicherheitsereignisse und Warnungen</p>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <!-- Filter -->
            <div class="card mb-4">
                <div class="flex gap-3 flex-wrap">
                    <button class="btn btn-secondary btn-sm filter-btn active" data-filter="all">Alle</button>
                    <button class="btn btn-secondary btn-sm filter-btn" data-filter="critical">
                        <span style="color: var(--danger);">●</span> Kritisch
                    </button>
                    <button class="btn btn-secondary btn-sm filter-btn" data-filter="warning">
                        <span style="color: var(--warning);">●</span> Warnung
                    </button>
                    <button class="btn btn-secondary btn-sm filter-btn" data-filter="info">
                        <span style="color: var(--info);">●</span> Info
                    </button>
                </div>
            </div>
            
            <div class="card">
                <div class="log-entries" id="logEntries">
                    <?php if (empty($logs)): ?>
                        <p class="text-muted text-center" style="padding: 2rem;">Keine Security-Logs vorhanden</p>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <div class="log-entry <?= $log['severity'] ?>" data-severity="<?= $log['severity'] ?>">
                                <span class="log-time"><?= formatDateTime($log['timestamp']) ?></span>
                                <span class="log-type badge badge-<?= $log['severity'] === 'critical' ? 'danger' : ($log['severity'] === 'warning' ? 'warning' : 'info') ?>">
                                    <?= strtoupper($log['type']) ?>
                                </span>
                                <span class="ip-display"><?= htmlspecialchars($log['ip']) ?></span>
                                <?php if (!empty($log['data'])): ?>
                                    <div class="mt-1 text-small text-muted">
                                        <?php foreach ($log['data'] as $key => $value): ?>
                                            <span class="badge badge-secondary"><?= $key ?>: <?= is_string($value) ? htmlspecialchars($value) : json_encode($value) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const filter = this.dataset.filter;
                
                // Update active state
                document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                // Filter entries
                document.querySelectorAll('.log-entry').forEach(entry => {
                    if (filter === 'all' || entry.dataset.severity === filter) {
                        entry.style.display = 'block';
                    } else {
                        entry.style.display = 'none';
                    }
                });
            });
        });
    </script>
</body>
</html>
