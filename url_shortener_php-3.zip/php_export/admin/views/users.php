<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benutzer - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header flex justify-between items-center">
                <div>
                    <h1 class="page-title">Benutzer verwalten</h1>
                    <p class="page-subtitle"><?= count($users) ?> Benutzer registriert</p>
                </div>
                <button class="btn btn-primary" onclick="openModal('createModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    Neuer Benutzer
                </button>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Benutzername</th>
                            <th>Rolle</th>
                            <th>Berechtigungen</th>
                            <th>Status</th>
                            <th>Letzter Login</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($user['username']) ?></strong>
                                <?php if ($user['id'] === $_SESSION['user_id']): ?>
                                    <span class="badge badge-info">Du</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge badge-<?= $user['role'] === 'admin' ? 'success' : 'secondary' ?>">
                                    <?= $user['role'] === 'admin' ? 'Administrator' : 'Benutzer' ?>
                                </span>
                            </td>
                            <td>
                                <div class="flex flex-wrap gap-1">
                                    <?php if ($user['role'] === 'admin'): ?>
                                        <span class="badge badge-success">Alle Rechte</span>
                                    <?php elseif (!empty($user['permissions'])): ?>
                                        <?php foreach (array_slice($user['permissions'], 0, 3) as $perm): ?>
                                            <span class="badge badge-secondary"><?= $perm ?></span>
                                        <?php endforeach; ?>
                                        <?php if (count($user['permissions']) > 3): ?>
                                            <span class="badge badge-info">+<?= count($user['permissions']) - 3 ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted text-small">Keine</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<?= $user['active'] ? 'success' : 'danger' ?>">
                                    <?= $user['active'] ? 'Aktiv' : 'Inaktiv' ?>
                                </span>
                            </td>
                            <td class="text-small text-muted">
                                <?= $user['last_login'] ? formatDateTime($user['last_login']) : 'Nie' ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn btn-secondary btn-sm btn-icon" onclick="editUser('<?= htmlspecialchars(json_encode($user)) ?>')" title="Bearbeiten">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                                    </button>
                                    <?php if ($user['id'] !== $_SESSION['user_id']): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Benutzer wirklich löschen?');">
                                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                        <button type="submit" class="btn btn-danger btn-sm btn-icon" title="Löschen">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <!-- Create Modal -->
    <div class="modal-overlay" id="createModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Neuen Benutzer erstellen</h3>
                <button class="modal-close" onclick="closeModal('createModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                <input type="hidden" name="action" value="create">
                
                <div class="form-group">
                    <label class="form-label" for="username">Benutzername *</label>
                    <input type="text" id="username" name="username" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="password">Passwort *</label>
                    <input type="password" id="password" name="password" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="role">Rolle</label>
                    <select id="role" name="role" class="form-select" onchange="togglePermissions(this.value)">
                        <option value="user">Benutzer</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>
                
                <div class="form-group" id="permissionsGroup">
                    <label class="form-label">Berechtigungen</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                        <?php foreach (PERMISSIONS as $key => $label): ?>
                        <label class="checkbox-wrapper">
                            <input type="checkbox" name="permissions[]" value="<?= $key ?>">
                            <span class="text-small"><?= $label ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="flex gap-2 justify-between">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('createModal')">Abbrechen</button>
                    <button type="submit" class="btn btn-primary">Erstellen</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div class="modal-overlay" id="editModal">
        <div class="modal">
            <div class="modal-header">
                <h3 class="modal-title">Benutzer bearbeiten</h3>
                <button class="modal-close" onclick="closeModal('editModal')">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            
            <form method="POST" id="editForm">
                <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="form-group">
                    <label class="form-label">Benutzername</label>
                    <input type="text" id="edit_username" class="form-input" disabled>
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_password">Neues Passwort (leer lassen = unverändert)</label>
                    <input type="password" id="edit_password" name="password" class="form-input">
                </div>
                
                <div class="form-group">
                    <label class="form-label" for="edit_role">Rolle</label>
                    <select id="edit_role" name="role" class="form-select" onchange="toggleEditPermissions(this.value)">
                        <option value="user">Benutzer</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>
                
                <div class="form-group" id="editPermissionsGroup">
                    <label class="form-label">Berechtigungen</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                        <?php foreach (PERMISSIONS as $key => $label): ?>
                        <label class="checkbox-wrapper">
                            <input type="checkbox" name="permissions[]" value="<?= $key ?>" id="edit_perm_<?= $key ?>">
                            <span class="text-small"><?= $label ?></span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="checkbox-wrapper">
                        <input type="checkbox" name="active" id="edit_active">
                        <span>Benutzer aktiv</span>
                    </label>
                </div>
                
                <div class="flex gap-2 justify-between">
                    <button type="button" class="btn btn-secondary" onclick="closeModal('editModal')">Abbrechen</button>
                    <button type="submit" class="btn btn-primary">Speichern</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function openModal(id) {
            document.getElementById(id).classList.add('active');
        }
        
        function closeModal(id) {
            document.getElementById(id).classList.remove('active');
        }
        
        function togglePermissions(role) {
            document.getElementById('permissionsGroup').style.display = role === 'admin' ? 'none' : 'block';
        }
        
        function toggleEditPermissions(role) {
            document.getElementById('editPermissionsGroup').style.display = role === 'admin' ? 'none' : 'block';
        }
        
        function editUser(userJson) {
            const user = JSON.parse(userJson);
            document.getElementById('edit_user_id').value = user.id;
            document.getElementById('edit_username').value = user.username;
            document.getElementById('edit_role').value = user.role;
            document.getElementById('edit_active').checked = user.active;
            
            // Reset all checkboxes
            document.querySelectorAll('#editPermissionsGroup input[type="checkbox"]').forEach(cb => cb.checked = false);
            
            // Set user permissions
            if (user.permissions) {
                user.permissions.forEach(perm => {
                    const cb = document.getElementById('edit_perm_' + perm);
                    if (cb) cb.checked = true;
                });
            }
            
            toggleEditPermissions(user.role);
            openModal('editModal');
        }
        
        // Close modal on escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
            }
        });
        
        // Close modal on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>
