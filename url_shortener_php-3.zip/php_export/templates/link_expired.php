<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link abgelaufen - URL Shortener</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="public-container">
        <div class="public-card">
            <svg class="public-icon warning" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/>
                <polyline points="12 6 12 12 16 14"/>
            </svg>
            
            <h1>Link abgelaufen</h1>
            <p class="text-muted mt-2">Die Gültigkeitsdauer ist überschritten</p>
            
            <p class="mt-4 text-secondary">
                Dieser Kurzlink hatte eine begrenzte Gültigkeitsdauer, die inzwischen abgelaufen ist.
            </p>
            
            <a href="/" class="btn btn-secondary mt-4">
                Zur Startseite
            </a>
        </div>
    </div>
</body>
</html>
