<?php
$success = false;
$error = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once BASE_PATH . '/classes/Database.php';
    require_once BASE_PATH . '/classes/Security.php';
    
    $db = new Database();
    $security = new Security();
    $visitor_data = $security->getVisitorData();
    
    $message_data = [
        'type' => 'unban_request',
        'ip' => $visitor_data['ip'],
        'email' => htmlspecialchars($_POST['email'] ?? ''),
        'reason' => htmlspecialchars($_POST['reason'] ?? ''),
        'visitor_data' => $visitor_data
    ];
    
    $db->addMessage($message_data);
    $db->addLog('message', 'Unban request received', $message_data);
    
    $success = true;
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entbannung beantragen - EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="container">
        <div class="card card-elevated" style="max-width: 600px; margin: 3rem auto;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="width: 80px; height: 80px; margin: 0 auto 1rem; background: rgba(239, 68, 68, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <svg style="width: 40px; height: 40px; fill: var(--color-danger);" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M13.477 14.89A6 6 0 015.11 6.524l8.367 8.368zm1.414-1.414L6.524 5.11a6 6 0 018.367 8.367zM18 10a8 8 0 11-16 0 8 8 0 0116 0z" clip-rule="evenodd"/>
                    </svg>
                </div>
                <h1 style="color: var(--color-danger); margin-bottom: 0.5rem;">Zugriff gesperrt</h1>
                <p class="text-muted">Ihre IP-Adresse wurde vom System gebannt</p>
            </div>
            
            <?php if ($success): ?>
                <div style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 8px; padding: 1.5rem; text-align: center; margin-bottom: 2rem;">
                    <svg style="width: 40px; height: 40px; fill: var(--color-success); margin-bottom: 1rem;" viewBox="0 0 20 20">
                        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
                    </svg>
                    <h2 style="color: var(--color-success); font-size: 1.25rem; margin-bottom: 0.5rem;">Anfrage gesendet</h2>
                    <p style="color: var(--color-text-secondary); font-size: 0.875rem;">
                        Ihre Entbannungs-Anfrage wurde an den Administrator weitergeleitet. 
                        Sie erhalten eine Rückmeldung per E-Mail.
                    </p>
                </div>
                
                <a href="/" class="btn btn-secondary" style="width: 100%; justify-content: center;">
                    Zurück zur Startseite
                </a>
            <?php else: ?>
                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Ihre E-Mail-Adresse</label>
                        <input type="email" name="email" class="form-input" required placeholder="ihre.email@example.com">
                        <p class="text-muted" style="font-size: 0.875rem; margin-top: 0.25rem;">
                            Wir benötigen Ihre E-Mail für die Rückmeldung
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Grund für die Entbannung</label>
                        <textarea name="reason" class="form-textarea" required placeholder="Bitte beschreiben Sie, warum Sie entsperrt werden möchten..."></textarea>
                        <p class="text-muted" style="font-size: 0.875rem; margin-top: 0.25rem;">
                            Eine ausführliche Begründung beschleunigt die Bearbeitung
                        </p>
                    </div>
                    
                    <div style="background: var(--color-bg-tertiary); border-radius: 8px; padding: 1rem; margin-bottom: 1.5rem;">
                        <p style="font-size: 0.875rem; color: var(--color-text-secondary);">
                            <strong style="color: var(--color-text-primary);">Hinweis:</strong> 
                            Der Administrator prüft Ihre Anfrage manuell. Die Bearbeitung kann einige Zeit in Anspruch nehmen.
                        </p>
                    </div>
                    
                    <div class="flex gap-2">
                        <a href="/" class="btn btn-secondary" style="flex: 1; justify-content: center;">
                            Abbrechen
                        </a>
                        <button type="submit" class="btn btn-primary" style="flex: 1; justify-content: center;">
                            Anfrage senden
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
