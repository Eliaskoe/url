<?php
/**
 * Database Klasse
 * Verwaltet JSON-basierte Datenspeicherung
 */
class Database {
    private $links_file;
    private $logs_file;
    private $bans_file;
    private $messages_file;
    
    public function __construct() {
        // JSON Dateien initialisieren
        $this->links_file = DATA_PATH . '/links.json';
        $this->logs_file = DATA_PATH . '/logs.json';
        $this->bans_file = DATA_PATH . '/bans.json';
        $this->messages_file = DATA_PATH . '/messages.json';
        
        // Dateien erstellen wenn nicht vorhanden
        $this->initializeFiles();
    }
    
    private function initializeFiles() {
        if (!is_dir(DATA_PATH)) {
            mkdir(DATA_PATH, 0755, true);
        }
        
        if (!file_exists($this->links_file)) {
            file_put_contents($this->links_file, json_encode([], JSON_PRETTY_PRINT));
        }
        if (!file_exists($this->logs_file)) {
            file_put_contents($this->logs_file, json_encode([], JSON_PRETTY_PRINT));
        }
        if (!file_exists($this->bans_file)) {
            file_put_contents($this->bans_file, json_encode([], JSON_PRETTY_PRINT));
        }
        if (!file_exists($this->messages_file)) {
            file_put_contents($this->messages_file, json_encode([], JSON_PRETTY_PRINT));
        }
    }
    
    private function readJson($file) {
        $content = file_get_contents($file);
        return json_decode($content, true) ?? [];
    }
    
    private function writeJson($file, $data) {
        file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    
    // Links
    public function getAllLinks() {
        return $this->readJson($this->links_file);
    }
    
    public function getLinkBySlug($slug) {
        $links = $this->getAllLinks();
        return $links[$slug] ?? null;
    }
    
    public function createLink($slug, $target_url, $options = []) {
        $links = $this->getAllLinks();
        
        $links[$slug] = [
            'slug' => $slug,
            'target_url' => $target_url,
            'status' => $options['status'] ?? 'active',
            'show_warning' => $options['show_warning'] ?? false,
            'expires_at' => $options['expires_at'] ?? null,
            'created_at' => date('Y-m-d H:i:s'),
            'created_by' => 'admin',
            'clicks' => 0
        ];
        
        $this->writeJson($this->links_file, $links);
        return $links[$slug];
    }
    
    public function updateLink($slug, $data) {
        $links = $this->getAllLinks();
        if (isset($links[$slug])) {
            $links[$slug] = array_merge($links[$slug], $data);
            $this->writeJson($this->links_file, $links);
            return true;
        }
        return false;
    }
    
    public function deleteLink($slug) {
        $links = $this->getAllLinks();
        if (isset($links[$slug])) {
            unset($links[$slug]);
            $this->writeJson($this->links_file, $links);
            return true;
        }
        return false;
    }
    
    // Logs
    public function getAllLogs() {
        return $this->readJson($this->logs_file);
    }
    
    public function addLog($type, $message, $data = []) {
        $logs = $this->getAllLogs();
        $logs[] = [
            'id' => uniqid(),
            'type' => $type,
            'message' => $message,
            'data' => $data,
            'timestamp' => date('Y-m-d H:i:s')
        ];
        
        // Nur letzte 1000 Logs behalten
        if (count($logs) > 1000) {
            $logs = array_slice($logs, -1000);
        }
        
        $this->writeJson($this->logs_file, $logs);
    }
    
    // Bans
    public function getAllBans() {
        return $this->readJson($this->bans_file);
    }
    
    public function addBan($ip, $reason = '', $duration = null) {
        $bans = $this->getAllBans();
        $bans[$ip] = [
            'ip' => $ip,
            'reason' => $reason,
            'banned_at' => date('Y-m-d H:i:s'),
            'expires_at' => $duration ? date('Y-m-d H:i:s', time() + $duration) : null
        ];
        $this->writeJson($this->bans_file, $bans);
    }
    
    public function removeBan($ip) {
        $bans = $this->getAllBans();
        if (isset($bans[$ip])) {
            unset($bans[$ip]);
            $this->writeJson($this->bans_file, $bans);
            return true;
        }
        return false;
    }
    
    public function isBanned($ip) {
        $bans = $this->getAllBans();
        if (isset($bans[$ip])) {
            $ban = $bans[$ip];
            // Temporären Ban prüfen
            if ($ban['expires_at'] && strtotime($ban['expires_at']) < time()) {
                $this->removeBan($ip);
                return false;
            }
            return true;
        }
        return false;
    }
    
    // Messages
    public function getAllMessages() {
        return $this->readJson($this->messages_file);
    }
    
    public function addMessage($data) {
        $messages = $this->getAllMessages();
        $id = uniqid();
        $messages[$id] = array_merge($data, [
            'id' => $id,
            'created_at' => date('Y-m-d H:i:s'),
            'status' => 'pending'
        ]);
        $this->writeJson($this->messages_file, $messages);
        return $id;
    }
    
    public function updateMessage($id, $data) {
        $messages = $this->getAllMessages();
        if (isset($messages[$id])) {
            $messages[$id] = array_merge($messages[$id], $data);
            $this->writeJson($this->messages_file, $messages);
            return true;
        }
        return false;
    }
}
