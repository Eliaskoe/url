#!/bin/bash

# URL Shortener - Setup & Autorun Script
# Domain: url.edk.codes
# 
# Dieses Script:
# 1. Setzt die richtigen Berechtigungen
# 2. Erstellt den Admin-Benutzer
# 3. Initialisiert die Daten-Dateien

echo "======================================"
echo "  URL Shortener - Setup"
echo "  Domain: url.edk.codes"
echo "======================================"
echo ""

# Arbeitsverzeichnis ermitteln
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "[1/4] Erstelle Verzeichnisstruktur..."
mkdir -p data
mkdir -p assets/css
mkdir -p assets/js
mkdir -p admin/views/partials
mkdir -p templates

echo "[2/4] Setze Berechtigungen..."
chmod 755 "$SCRIPT_DIR"
chmod -R 755 admin includes templates assets
chmod -R 777 data

echo "[3/4] Initialisiere Daten-Dateien..."

# users.json wird durch setup.php erstellt
echo '[]' > data/users.json
echo "Führe setup.php aus um Admin-Benutzer zu erstellen..."
php setup.php

# Leere JSON-Dateien erstellen
echo '[]' > data/links.json
echo '[]' > data/visitors.json
echo '[]' > data/security_logs.json
echo '[]' > data/clicks.json
echo '[]' > data/bans.json
echo '[]' > data/unban_requests.json
echo '{"site_name": "URL Shortener", "domain": "url.edk.codes"}' > data/settings.json

echo "[4/4] Erstelle nginx-Konfiguration..."

cat > nginx.conf.example << 'EOF'
# Nginx Konfiguration für URL Shortener
# Speichern unter: /etc/nginx/sites-available/url.edk.codes

server {
    listen 80;
    listen [::]:80;
    server_name url.edk.codes;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name url.edk.codes;

    # SSL-Zertifikate (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/url.edk.codes/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/url.edk.codes/privkey.pem;

    # Root-Verzeichnis
    root /var/www/edk/url.edk;
    index index.php;

    # Sicherheitsheader
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Logs
    access_log /var/log/nginx/url.edk.codes.access.log;
    error_log /var/log/nginx/url.edk.codes.error.log;

    # Statische Dateien
    location /assets/ {
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # PHP-Verarbeitung
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_intercept_errors on;
    }

    # Sicherheit: Verstecke sensible Dateien
    location ~ /\. {
        deny all;
    }

    location ~ ^/data/ {
        deny all;
    }

    location ~ ^/includes/ {
        deny all;
    }
}
EOF

echo ""
echo "======================================"
echo "  Setup abgeschlossen!"
echo "======================================"
echo ""
echo "Admin-Zugangsdaten:"
echo "  Benutzername: Elias061010"
echo "  Passwort:     Elias061010"
echo ""
echo "WICHTIG: Ändere das Passwort nach dem ersten Login!"
echo ""
echo "Nächste Schritte:"
echo "  1. Kopiere alle Dateien nach /var/www/edk/url.edk/"
echo "  2. Kopiere nginx.conf.example nach /etc/nginx/sites-available/"
echo "  3. Aktiviere die Site: ln -s /etc/nginx/sites-available/url.edk.codes /etc/nginx/sites-enabled/"
echo "  4. Teste nginx: nginx -t"
echo "  5. Starte nginx neu: systemctl restart nginx"
echo ""
echo "Admin-Panel: https://url.edk.codes/cadmin"
echo ""
