# EDK URL Shortener - Installationsanleitung

## Voraussetzungen

- PHP 8.0 oder höher
- Nginx oder Apache Webserver
- JSON-Unterstützung (standardmäßig in PHP enthalten)

## Installation auf Nginx

### 1. Dateien hochladen

```bash
# Alle Dateien nach /var/www/edk/url.edk/ kopieren
sudo mkdir -p /var/www/edk/url.edk
cd /var/www/edk/url.edk
# Dateien hier hochladen/entpacken
```

### 2. Berechtigungen setzen

```bash
# Eigentümer setzen
sudo chown -R www-data:www-data /var/www/edk/url.edk

# Basis-Berechtigungen
sudo chmod -R 755 /var/www/edk/url.edk

# Data-Verzeichnis beschreibbar machen
sudo chmod -R 775 /var/www/edk/url.edk/data

# Sicherstellen dass www-data schreiben kann
sudo chgrp -R www-data /var/www/edk/url.edk/data
```

### 3. Nginx konfigurieren

```bash
# Konfiguration kopieren
sudo nano /etc/nginx/sites-available/url.edk.codes

# Inhalt aus .nginx-example.conf einfügen und anpassen

# Symlink erstellen
sudo ln -s /etc/nginx/sites-available/url.edk.codes /etc/nginx/sites-enabled/

# Nginx-Konfiguration testen
sudo nginx -t

# Nginx neu laden
sudo systemctl reload nginx
```

### 4. PHP-FPM prüfen

```bash
# Status prüfen
sudo systemctl status php8.2-fpm

# Falls nicht installiert
sudo apt update
sudo apt install php8.2-fpm php8.2-json php8.2-mbstring
```

### 5. Erste Schritte

1. Öffnen Sie `http://url.edk.codes` in Ihrem Browser
2. Gehen Sie zu `/cadmin` für den Admin-Zugang
3. Standard-Login: Passwort `admin123`
4. **WICHTIG**: Ändern Sie das Passwort!

## Passwort ändern

### Neues Passwort generieren

```php
<?php
// Diesen Code in einer separaten PHP-Datei ausführen
$new_password = 'IhrNeuesPasswort123';
echo password_hash($new_password, PASSWORD_DEFAULT);
?>
```

### In admin/controller.php einfügen

```php
// Zeile 9 in admin/controller.php
define('ADMIN_PASSWORD_HASH', 'HIER_IHR_NEUER_HASH');
```

## Sicherheitshinweise

### Secret Key ändern

In `classes/Security.php` Zeile 8:

```php
private $secret_key = 'HIER_EINEN_LANGEN_ZUFÄLLIGEN_STRING';
```

Generieren Sie einen sicheren Schlüssel:

```bash
openssl rand -base64 32
```

### Data-Verzeichnis schützen

Die `.htaccess` Datei in `/data/` schützt bereits vor direktem Zugriff bei Apache.
Nginx blockiert den Zugriff über die Konfigurationsdatei.

### HTTPS aktivieren (empfohlen)

```bash
# Let's Encrypt installieren
sudo apt install certbot python3-certbot-nginx

# Zertifikat erstellen
sudo certbot --nginx -d url.edk.codes

# Automatische Erneuerung testen
sudo certbot renew --dry-run
```

## Fehlerbehebung

### Dateien können nicht geschrieben werden

```bash
# Berechtigungen prüfen
ls -la /var/www/edk/url.edk/data

# Falls nötig, neu setzen
sudo chmod -R 775 /var/www/edk/url.edk/data
sudo chown -R www-data:www-data /var/www/edk/url.edk/data
```

### 404-Fehler bei allen Links

Nginx-Konfiguration prüfen:

```bash
sudo nginx -t
sudo tail -f /var/log/nginx/url.edk.codes-error.log
```

### PHP-Fehler

```bash
# PHP Error Log prüfen
sudo tail -f /var/log/php8.2-fpm.log

# In index.php Error Reporting aktivieren (nur für Debugging!)
ini_set('display_errors', 1);
error_reporting(E_ALL);
```

### JSON-Dateien beschädigt

```bash
# Backup erstellen
cp -r /var/www/edk/url.edk/data /var/www/edk/url.edk/data.backup

# Dateien neu initialisieren
rm /var/www/edk/url.edk/data/*.json
# System öffnen - Dateien werden automatisch neu erstellt
```

## Backup

### Automatisches Backup einrichten

```bash
# Backup-Script erstellen
sudo nano /usr/local/bin/backup-edk-urls.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/var/backups/edk-url-shortener"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR
tar -czf $BACKUP_DIR/backup_$DATE.tar.gz /var/www/edk/url.edk/data

# Alte Backups löschen (älter als 30 Tage)
find $BACKUP_DIR -name "backup_*.tar.gz" -mtime +30 -delete
```

```bash
# Ausführbar machen
sudo chmod +x /usr/local/bin/backup-edk-urls.sh

# Cron-Job einrichten (täglich um 3 Uhr)
sudo crontab -e
# Folgende Zeile hinzufügen:
0 3 * * * /usr/local/bin/backup-edk-urls.sh
```

## Support

Bei Problemen:
1. Logs prüfen (Nginx + PHP-FPM)
2. Berechtigungen überprüfen
3. Browser-Console auf JavaScript-Fehler prüfen
4. Admin-Logs im System ansehen

## Erweiterte Konfiguration

### GeoIP-Integration (optional)

Für echte Geo-Location-Daten können Sie einen Service wie MaxMind GeoIP2 integrieren:

```php
// In classes/Security.php getCountryFromIP() Methode
private function getCountryFromIP() {
    // MaxMind GeoIP2 API Integration hier
    // Oder anderen GeoIP-Service verwenden
}
```

### Email-Benachrichtigungen (optional)

Fügen Sie in `admin/views/messages.php` Email-Versand hinzu:

```php
// Nach erfolgreicher Antwort
mail($message['email'], 'Antwort auf Ihre Anfrage', $reply);
```

## Wartung

### Logs bereinigen

```bash
# Über Admin-Panel oder direkt:
# Alte Logs aus logs.json entfernen
# Automatische Bereinigung ist im Code implementiert (max 1000 Einträge)
```

### System-Updates

```bash
# System aktualisieren
sudo apt update && sudo apt upgrade

# PHP updaten
sudo apt install php8.3-fpm php8.3-json php8.3-mbstring

# Nginx-Konfiguration anpassen (PHP-Version)
sudo nano /etc/nginx/sites-available/url.edk.codes
```

## Produktiv-Checklist

- [ ] Standard-Passwort geändert
- [ ] Secret Key in Security.php geändert
- [ ] HTTPS aktiviert
- [ ] Berechtigungen korrekt gesetzt
- [ ] Backup-System eingerichtet
- [ ] Error Reporting in index.php deaktiviert
- [ ] Nginx-Logs überwacht
- [ ] Firewall konfiguriert (nur Port 80/443 offen)
