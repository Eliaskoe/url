<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Besucher - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Besucher-Logs</h1>
                <p class="page-subtitle">Letzte <?= count($visitors) ?> Besucher</p>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>IP-Adresse</th>
                            <th>User-Agent</th>
                            <th>Seite</th>
                            <th>Referer</th>
                            <th>Session</th>
                            <th>Zeitpunkt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($visitors)): ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted" style="padding: 2rem;">Keine Besucher-Logs vorhanden</td>
                            </tr>
                        <?php else: ?>
                            <?php 
                            $securityObj = new Security();
                            foreach ($visitors as $visitor): 
                                $uaInfo = $securityObj->parseUserAgent($visitor['user_agent'] ?? '');
                            ?>
                            <tr>
                                <td>
                                    <span class="ip-display"><?= htmlspecialchars($visitor['ip']) ?></span>
                                    <?php if ($auth->hasPermission('manage_bans')): ?>
                                    <form method="POST" action="<?= ADMIN_PATH ?>/bans" style="display: inline;">
                                        <input type="hidden" name="csrf_token" value="<?= generateCSRFToken() ?>">
                                        <input type="hidden" name="action" value="ban">
                                        <input type="hidden" name="ip" value="<?= htmlspecialchars($visitor['ip']) ?>">
                                        <input type="hidden" name="reason" value="Manuell gebannt">
                                        <button type="submit" class="btn btn-danger btn-sm" style="padding: 0.2rem 0.5rem; font-size: 0.7rem;" onclick="return confirm('IP bannen?');">Ban</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="text-small">
                                        <span class="badge badge-secondary"><?= htmlspecialchars($uaInfo['browser']) ?></span>
                                        <span class="badge badge-secondary"><?= htmlspecialchars($uaInfo['os']) ?></span>
                                    </div>
                                    <div class="text-xs text-muted" style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($visitor['user_agent'] ?? '') ?>">
                                        <?= htmlspecialchars($visitor['user_agent'] ?? 'Unbekannt') ?>
                                    </div>
                                </td>
                                <td>
                                    <code class="text-small"><?= htmlspecialchars($visitor['request_uri'] ?? '/') ?></code>
                                </td>
                                <td>
                                    <?php if (!empty($visitor['referer'])): ?>
                                        <span class="text-small text-muted" style="max-width: 150px; display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($visitor['referer']) ?>">
                                            <?= htmlspecialchars($visitor['referer']) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <code class="text-xs"><?= htmlspecialchars(substr($visitor['session_id'] ?? '', 0, 8)) ?>...</code>
                                </td>
                                <td class="text-small text-muted">
                                    <?= formatDateTime($visitor['timestamp']) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>
