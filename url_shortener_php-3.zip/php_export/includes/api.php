<?php
/**
 * API Endpoints
 */

header('Content-Type: application/json');

$storage = new Storage();
$auth = new Auth();
$security = new Security();

$method = $_SERVER['REQUEST_METHOD'];
$path = trim(str_replace('api/', '', $path), '/');

// CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($method === 'OPTIONS') {
    exit;
}

// JSON Input
$input = json_decode(file_get_contents('php://input'), true) ?? [];

// Öffentliche Endpoints
switch ($path) {
    case 'unban-request':
        if ($method === 'POST') {
            $ip = $security->getClientIP();
            
            if (empty($input['message'])) {
                jsonResponse(['error' => 'Nachricht erforderlich'], 400);
            }
            
            $request = $storage->createUnbanRequest([
                'ip' => $ip,
                'email' => $input['email'] ?? '',
                'message' => sanitize($input['message'])
            ]);
            
            jsonResponse(['success' => true, 'message' => 'Antrag eingereicht']);
        }
        break;
}

// Auth-geschützte Endpoints
if (!$auth->isLoggedIn()) {
    jsonResponse(['error' => 'Nicht autorisiert'], 401);
}

// API Routing
switch ($path) {
    // ==================== LINKS ====================
    case 'links':
        if ($method === 'GET') {
            if (!$auth->hasPermission('view_links')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            jsonResponse($storage->getLinks());
        }
        
        if ($method === 'POST') {
            if (!$auth->hasPermission('manage_links')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            
            if (empty($input['target_url']) || !isValidUrl($input['target_url'])) {
                jsonResponse(['error' => 'Ungültige URL'], 400);
            }
            
            $link = $storage->createLink([
                'target_url' => $input['target_url'],
                'slug' => $input['slug'] ?? null,
                'title' => $input['title'] ?? '',
                'warning_page' => $input['warning_page'] ?? false,
                'expires_at' => $input['expires_at'] ?? null,
                'created_by' => $_SESSION['user_id']
            ]);
            
            jsonResponse($link, 201);
        }
        break;
    
    case (preg_match('/^links\/([a-zA-Z0-9-]+)$/', $path, $m) ? true : false):
        $linkId = $m[1];
        
        if ($method === 'GET') {
            if (!$auth->hasPermission('view_links')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            $link = $storage->getLinkById($linkId);
            if (!$link) {
                jsonResponse(['error' => 'Link nicht gefunden'], 404);
            }
            jsonResponse($link);
        }
        
        if ($method === 'PUT') {
            if (!$auth->hasPermission('manage_links')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            $storage->updateLink($linkId, $input);
            jsonResponse(['success' => true]);
        }
        
        if ($method === 'DELETE') {
            if (!$auth->hasPermission('manage_links')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            $storage->deleteLink($linkId);
            jsonResponse(['success' => true]);
        }
        break;
    
    // ==================== USERS ====================
    case 'users':
        if (!$auth->hasPermission('manage_users')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        if ($method === 'GET') {
            $users = $storage->getUsers();
            // Passwörter entfernen
            $users = array_map(function($u) {
                unset($u['password']);
                return $u;
            }, $users);
            jsonResponse($users);
        }
        
        if ($method === 'POST') {
            if (empty($input['username']) || empty($input['password'])) {
                jsonResponse(['error' => 'Benutzername und Passwort erforderlich'], 400);
            }
            
            if ($storage->getUserByUsername($input['username'])) {
                jsonResponse(['error' => 'Benutzername existiert bereits'], 400);
            }
            
            $user = $storage->createUser($input);
            unset($user['password']);
            jsonResponse($user, 201);
        }
        break;
    
    case (preg_match('/^users\/([a-zA-Z0-9-]+)$/', $path, $m) ? true : false):
        $userId = $m[1];
        
        if (!$auth->hasPermission('manage_users')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        if ($method === 'PUT') {
            $storage->updateUser($userId, $input);
            jsonResponse(['success' => true]);
        }
        
        if ($method === 'DELETE') {
            // Eigenen Account nicht löschen
            if ($userId === $_SESSION['user_id']) {
                jsonResponse(['error' => 'Eigenen Account nicht löschbar'], 400);
            }
            $storage->deleteUser($userId);
            jsonResponse(['success' => true]);
        }
        break;
    
    // ==================== VISITORS ====================
    case 'visitors':
        if (!$auth->hasPermission('view_visitors')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        $limit = intval($_GET['limit'] ?? 100);
        $offset = intval($_GET['offset'] ?? 0);
        jsonResponse($storage->getVisitorLogs($limit, $offset));
        break;
    
    // ==================== SECURITY LOGS ====================
    case 'security-logs':
        if (!$auth->hasPermission('view_security')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        $limit = intval($_GET['limit'] ?? 100);
        $offset = intval($_GET['offset'] ?? 0);
        jsonResponse($storage->getSecurityLogs($limit, $offset));
        break;
    
    // ==================== BANS ====================
    case 'bans':
        if ($method === 'GET') {
            if (!$auth->hasPermission('view_bans')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            jsonResponse($storage->getBans());
        }
        
        if ($method === 'POST') {
            if (!$auth->hasPermission('manage_bans')) {
                jsonResponse(['error' => 'Keine Berechtigung'], 403);
            }
            
            if (empty($input['ip'])) {
                jsonResponse(['error' => 'IP erforderlich'], 400);
            }
            
            $storage->banIP($input['ip'], $input['reason'] ?? '', $input['duration'] ?? null);
            $security->logSecurityEvent('ip_banned', ['ip' => $input['ip'], 'reason' => $input['reason'] ?? '']);
            jsonResponse(['success' => true]);
        }
        break;
    
    case (preg_match('/^bans\/unban\/(.+)$/', $path, $m) ? true : false):
        $ip = urldecode($m[1]);
        
        if (!$auth->hasPermission('manage_bans')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        if ($method === 'POST') {
            $storage->unbanIP($ip);
            $security->logSecurityEvent('ip_unbanned', ['ip' => $ip]);
            jsonResponse(['success' => true]);
        }
        break;
    
    // ==================== UNBAN REQUESTS ====================
    case 'unban-requests':
        if (!$auth->hasPermission('manage_unban_requests')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        if ($method === 'GET') {
            jsonResponse($storage->getUnbanRequests());
        }
        break;
    
    case (preg_match('/^unban-requests\/([a-zA-Z0-9-]+)$/', $path, $m) ? true : false):
        $requestId = $m[1];
        
        if (!$auth->hasPermission('manage_unban_requests')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        
        if ($method === 'PUT') {
            $storage->updateUnbanRequest($requestId, $input);
            
            // Bei Genehmigung IP entbannen
            if (($input['status'] ?? '') === 'approved') {
                $requests = $storage->getUnbanRequests();
                foreach ($requests as $req) {
                    if ($req['id'] === $requestId) {
                        $storage->unbanIP($req['ip']);
                        break;
                    }
                }
            }
            
            jsonResponse(['success' => true]);
        }
        break;
    
    // ==================== STATS ====================
    case 'stats':
        if (!$auth->hasPermission('view_dashboard')) {
            jsonResponse(['error' => 'Keine Berechtigung'], 403);
        }
        jsonResponse($storage->getStats());
        break;
    
    default:
        jsonResponse(['error' => 'Endpoint nicht gefunden'], 404);
}
