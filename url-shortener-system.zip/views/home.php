<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDK URL Shortener</title>
    <link rel="stylesheet" href="/assets/style.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <h1>EDK URL Shortener</h1>
            <p>Professioneller Link-Management Service</p>
        </header>
        
        <div class="grid grid-2" style="max-width: 1000px; margin: 0 auto;">
            <!-- Added welcome card with info -->
            <div class="card card-elevated">
                <h2 style="margin-bottom: 1rem; color: var(--color-blue-pastel);">Willkommen</h2>
                <p class="text-muted mb-3">Dieses System dient zum Verwalten und Umleiten von Kurzlinks.</p>
                
                <div class="mb-3">
                    <h3 style="font-size: 1rem; color: var(--color-text-primary); margin-bottom: 0.5rem;">So funktioniert's:</h3>
                    <ul style="color: var(--color-text-secondary); list-style: none; padding: 0;">
                        <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
                            <span class="badge badge-blue">1</span> Admin erstellt Kurzlink
                        </li>
                        <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
                            <span class="badge badge-blue">2</span> Nutzer ruft Link auf
                        </li>
                        <li style="padding: 0.5rem 0;">
                            <span class="badge badge-blue">3</span> Automatische Weiterleitung
                        </li>
                    </ul>
                </div>
                
                <div class="card" style="background: var(--color-bg-tertiary); border-color: var(--color-blue-dark);">
                    <p style="color: var(--color-text-secondary); font-size: 0.875rem; margin-bottom: 0.5rem;">
                        Link-Format:
                    </p>
                    <code style="color: var(--color-blue-light); font-size: 1rem; font-weight: 600;">
                        url.edk.codes/<span style="color: var(--color-blue-pastel);">ihr-slug</span>
                    </code>
                </div>
            </div>
            
            <!-- Added admin access card -->
            <div class="card card-elevated">
                <h2 style="margin-bottom: 1rem; color: var(--color-blue-pastel);">Administrator</h2>
                <p class="text-muted mb-3">Zugang zum Admin-Panel für Link-Verwaltung und Monitoring.</p>
                
                <div class="mb-3">
                    <h3 style="font-size: 1rem; color: var(--color-text-primary); margin-bottom: 0.5rem;">Features:</h3>
                    <ul style="color: var(--color-text-secondary); list-style: none; padding: 0;">
                        <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
                            <span style="color: var(--color-success);">✓</span> Links erstellen & verwalten
                        </li>
                        <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
                            <span style="color: var(--color-success);">✓</span> IP-Tracking & Logs
                        </li>
                        <li style="padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
                            <span style="color: var(--color-success);">✓</span> Ban-Management
                        </li>
                        <li style="padding: 0.5rem 0;">
                            <span style="color: var(--color-success);">✓</span> Statistiken & Monitoring
                        </li>
                    </ul>
                </div>
                
                <a href="/cadmin" class="btn btn-primary" style="width: 100%; justify-content: center;">
                    <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                        <path d="M10 2a5 5 0 00-5 5v2a2 2 0 00-2 2v5a2 2 0 002 2h10a2 2 0 002-2v-5a2 2 0 00-2-2H7V7a3 3 0 015.905-.75 1 1 0 001.937-.5A5.002 5.002 0 0010 2z"/>
                    </svg>
                    Admin-Panel öffnen
                </a>
            </div>
        </div>
        
        <!-- Added footer with system info -->
        <footer style="text-align: center; margin-top: 4rem; padding: 2rem 0; border-top: 1px solid var(--color-border);">
            <p class="text-muted" style="font-size: 0.875rem;">
                EDK URL Shortener - Sicher, Professionell, Übersichtlich
            </p>
        </footer>
    </div>
</body>
</html>
