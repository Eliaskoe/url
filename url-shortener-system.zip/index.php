<?php
/**
 * EDK URL Shortener - Front Controller
 * Entry Point für alle Requests
 */

// Error Reporting für Development
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Session starten mit sicheren Einstellungen
ini_set('session.cookie_httponly', 1);
ini_set('session.use_strict_mode', 1);
session_start();

// Konstanten
define('BASE_PATH', __DIR__);
define('DATA_PATH', BASE_PATH . '/data');
define('ADMIN_PATH', '/cadmin');

// Autoloader für Klassen
spl_autoload_register(function ($class) {
    $file = BASE_PATH . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// Request URI parsen
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$request_uri = rtrim($request_uri, '/');

// Router initialisieren
$router = new Router();

// Admin-Bereich prüfen
if (strpos($request_uri, ADMIN_PATH) === 0) {
    // Admin Controller laden
    require_once BASE_PATH . '/admin/controller.php';
    exit;
}

// Public Routes
if ($request_uri === '' || $request_uri === '/') {
    // Homepage - URL Shortener Interface
    require_once BASE_PATH . '/views/home.php';
} elseif ($request_uri === '/unban') {
    // Entbann-Antrag
    require_once BASE_PATH . '/views/unban.php';
} else {
    // Short URL Handler
    $slug = ltrim($request_uri, '/');
    $router->handleShortUrl($slug);
}
