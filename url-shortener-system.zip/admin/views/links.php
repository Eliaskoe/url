<?php
$page_title = 'Links verwalten';
require BASE_PATH . '/admin/includes/header.php';

$db = new Database();
$success = false;
$error = false;

// Link hinzufügen/bearbeiten
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'create') {
            $slug = trim($_POST['slug']);
            $target_url = trim($_POST['target_url']);
            
            if (empty($slug) || empty($target_url)) {
                $error = 'Slug und Ziel-URL sind erforderlich';
            } elseif ($db->getLinkBySlug($slug)) {
                $error = 'Dieser Slug existiert bereits';
            } else {
                $db->createLink($slug, $target_url, [
                    'status' => $_POST['status'] ?? 'active',
                    'show_warning' => isset($_POST['show_warning']),
                    'expires_at' => !empty($_POST['expires_at']) ? $_POST['expires_at'] : null
                ]);
                $db->addLog('admin', "Link created: /{$slug}", ['target' => $target_url]);
                $success = 'Link erfolgreich erstellt';
            }
        } elseif ($_POST['action'] === 'update') {
            $slug = $_POST['slug'];
            $db->updateLink($slug, [
                'target_url' => $_POST['target_url'],
                'status' => $_POST['status'],
                'show_warning' => isset($_POST['show_warning']),
                'expires_at' => !empty($_POST['expires_at']) ? $_POST['expires_at'] : null
            ]);
            $db->addLog('admin', "Link updated: /{$slug}");
            $success = 'Link erfolgreich aktualisiert';
        } elseif ($_POST['action'] === 'delete') {
            $slug = $_POST['slug'];
            $db->deleteLink($slug);
            $db->addLog('admin', "Link deleted: /{$slug}");
            $success = 'Link erfolgreich gelöscht';
        }
    }
}

$links = $db->getAllLinks();
?>

<?php if ($success): ?>
<div class="card" style="background: rgba(16, 185, 129, 0.1); border-color: var(--color-success); margin-bottom: 2rem;">
    <p style="color: var(--color-success); margin: 0; font-weight: 500;"><?php echo htmlspecialchars($success); ?></p>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="card" style="background: rgba(239, 68, 68, 0.1); border-color: var(--color-danger); margin-bottom: 2rem;">
    <p style="color: var(--color-danger); margin: 0; font-weight: 500;"><?php echo htmlspecialchars($error); ?></p>
</div>
<?php endif; ?>

<!-- Create Link Form -->
<div class="card mb-4">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">Neuen Link erstellen</h2>
    
    <form method="POST" class="grid grid-2">
        <input type="hidden" name="action" value="create">
        
        <div class="form-group">
            <label class="form-label">Slug (Kurzlink)</label>
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <span style="color: var(--color-text-muted);">url.edk.codes/</span>
                <input type="text" name="slug" class="form-input" required placeholder="mein-link" pattern="[a-zA-Z0-9-_]+" title="Nur Buchstaben, Zahlen, - und _">
            </div>
        </div>
        
        <div class="form-group">
            <label class="form-label">Ziel-URL</label>
            <input type="url" name="target_url" class="form-input" required placeholder="https://example.com">
        </div>
        
        <div class="form-group">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="active">Aktiv</option>
                <option value="inactive">Inaktiv</option>
            </select>
        </div>
        
        <div class="form-group">
            <label class="form-label">Ablaufzeit (optional)</label>
            <input type="datetime-local" name="expires_at" class="form-input">
        </div>
        
        <div class="form-group" style="grid-column: 1 / -1;">
            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                <input type="checkbox" name="show_warning" style="width: 18px; height: 18px;">
                <span class="form-label" style="margin: 0;">Vorschaltseite mit Warnung anzeigen</span>
            </label>
        </div>
        
        <div style="grid-column: 1 / -1;">
            <button type="submit" class="btn btn-primary">
                <svg style="width: 20px; height: 20px; fill: currentColor;" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd"/>
                </svg>
                Link erstellen
            </button>
        </div>
    </form>
</div>

<!-- Links Table -->
<div class="card">
    <h2 style="margin-bottom: 1.5rem; font-size: 1.25rem; color: var(--color-blue-pastel);">Alle Links (<?php echo count($links); ?>)</h2>
    
    <?php if (empty($links)): ?>
        <div style="text-align: center; padding: 3rem; color: var(--color-text-muted);">
            <p>Noch keine Links vorhanden</p>
        </div>
    <?php else: ?>
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>Slug</th>
                        <th>Ziel-URL</th>
                        <th>Status</th>
                        <th>Klicks</th>
                        <th>Erstellt</th>
                        <th>Aktionen</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($links as $link): ?>
                        <tr>
                            <td>
                                <code style="color: var(--color-blue-light); font-weight: 600;">
                                    /<?php echo htmlspecialchars($link['slug']); ?>
                                </code>
                            </td>
                            <td>
                                <div style="max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <a href="<?php echo htmlspecialchars($link['target_url']); ?>" target="_blank" style="color: var(--color-text-secondary); text-decoration: none;">
                                        <?php echo htmlspecialchars($link['target_url']); ?>
                                    </a>
                                </div>
                            </td>
                            <td>
                                <span class="badge <?php echo $link['status'] === 'active' ? 'badge-success' : 'badge-warning'; ?>">
                                    <?php echo $link['status'] === 'active' ? 'Aktiv' : 'Inaktiv'; ?>
                                </span>
                            </td>
                            <td>
                                <span style="font-weight: 600; color: var(--color-blue-light);">
                                    <?php echo $link['clicks'] ?? 0; ?>
                                </span>
                            </td>
                            <td class="text-muted" style="font-size: 0.875rem;">
                                <?php echo date('d.m.Y H:i', strtotime($link['created_at'])); ?>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button onclick="editLink('<?php echo htmlspecialchars(json_encode($link)); ?>')" class="btn btn-secondary btn-sm">
                                        Bearbeiten
                                    </button>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Link wirklich löschen?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="slug" value="<?php echo htmlspecialchars($link['slug']); ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            Löschen
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal-overlay" style="display: none;">
    <div class="modal">
        <div class="modal-header">
            <h3 style="margin: 0; color: var(--color-blue-pastel);">Link bearbeiten</h3>
            <button onclick="closeEditModal()" style="background: none; border: none; color: var(--color-text-muted); cursor: pointer; font-size: 1.5rem;">×</button>
        </div>
        <form method="POST" id="editForm">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="slug" id="edit_slug">
            
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Slug</label>
                    <input type="text" id="edit_slug_display" class="form-input" disabled>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Ziel-URL</label>
                    <input type="url" name="target_url" id="edit_target_url" class="form-input" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select name="status" id="edit_status" class="form-select">
                        <option value="active">Aktiv</option>
                        <option value="inactive">Inaktiv</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Ablaufzeit</label>
                    <input type="datetime-local" name="expires_at" id="edit_expires_at" class="form-input">
                </div>
                
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" name="show_warning" id="edit_show_warning" style="width: 18px; height: 18px;">
                        <span class="form-label" style="margin: 0;">Vorschaltseite mit Warnung anzeigen</span>
                    </label>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" onclick="closeEditModal()" class="btn btn-secondary">Abbrechen</button>
                <button type="submit" class="btn btn-primary">Speichern</button>
            </div>
        </form>
    </div>
</div>

<script>
function editLink(linkJson) {
    const link = JSON.parse(linkJson);
    document.getElementById('edit_slug').value = link.slug;
    document.getElementById('edit_slug_display').value = link.slug;
    document.getElementById('edit_target_url').value = link.target_url;
    document.getElementById('edit_status').value = link.status;
    document.getElementById('edit_expires_at').value = link.expires_at || '';
    document.getElementById('edit_show_warning').checked = link.show_warning || false;
    document.getElementById('editModal').style.display = 'flex';
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

// Close modal on outside click
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeEditModal();
    }
});
</script>

<?php require BASE_PATH . '/admin/includes/footer.php'; ?>
