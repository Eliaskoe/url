<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>URL Shortener - url.edk.codes</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="public-container">
        <div class="public-card">
            <svg class="public-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
            </svg>
            
            <h1>URL Shortener</h1>
            <p class="text-muted mt-2">url.edk.codes</p>
            
            <p class="mt-4 text-secondary">
                Professioneller URL-Kürzungsdienst mit erweiterten Sicherheitsfeatures.
            </p>
            
            <a href="<?= ADMIN_PATH ?>/login" class="btn btn-primary mt-4">
                Admin-Login
            </a>
        </div>
    </div>
</body>
</html>
