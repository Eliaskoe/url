<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - URL Shortener Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <div class="admin-layout">
        <?php include BASE_PATH . '/admin/views/partials/sidebar.php'; ?>
        
        <main class="main-content">
            <div class="page-header">
                <h1 class="page-title">Dashboard</h1>
                <p class="page-subtitle">Willkommen zurück, <?= htmlspecialchars($_SESSION['username']) ?></p>
            </div>
            
            <?php $flash = getFlash(); if ($flash): ?>
                <div class="alert alert-<?= $flash['type'] ?>">
                    <?= htmlspecialchars($flash['message']) ?>
                </div>
            <?php endif; ?>
            
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['total_links'] ?></div>
                        <div class="stat-label">Gesamt Links</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon green">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['total_clicks'] ?></div>
                        <div class="stat-label">Gesamt Klicks</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['today_visitors'] ?></div>
                        <div class="stat-label">Besucher Heute</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon red">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['active_bans'] ?></div>
                        <div class="stat-label">Aktive Bans</div>
                    </div>
                </div>
            </div>
            
            <!-- Second Row Stats -->
            <div class="stats-grid mb-4">
                <div class="stat-card">
                    <div class="stat-icon green">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['active_links'] ?></div>
                        <div class="stat-label">Aktive Links</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon blue">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['total_visitors'] ?></div>
                        <div class="stat-label">Gesamt Besucher</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon <?= $stats['critical_events'] > 0 ? 'red' : 'green' ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['critical_events'] ?></div>
                        <div class="stat-label">Kritische Events</div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon yellow">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                    </div>
                    <div class="stat-content">
                        <div class="stat-value"><?= $stats['total_security_events'] ?></div>
                        <div class="stat-label">Security Events</div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Activity -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Letzte Security-Events</h3>
                    <a href="<?= ADMIN_PATH ?>/security" class="btn btn-secondary btn-sm">Alle anzeigen</a>
                </div>
                
                <div class="log-entries">
                    <?php if (empty($recentLogs)): ?>
                        <p class="text-muted text-center" style="padding: 2rem;">Keine Events vorhanden</p>
                    <?php else: ?>
                        <?php foreach ($recentLogs as $log): ?>
                            <div class="log-entry <?= $log['severity'] ?>">
                                <span class="log-time"><?= formatDateTime($log['timestamp']) ?></span>
                                <span class="log-type">[<?= strtoupper($log['type']) ?>]</span>
                                <span class="ip-display"><?= htmlspecialchars($log['ip']) ?></span>
                                <?php if (!empty($log['data'])): ?>
                                    <span class="text-muted"> - <?= htmlspecialchars(json_encode($log['data'])) ?></span>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
